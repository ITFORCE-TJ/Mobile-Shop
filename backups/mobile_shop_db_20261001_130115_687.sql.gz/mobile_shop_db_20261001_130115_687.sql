--
-- PostgreSQL database dump
--

\restrict aneZmiEsNBDKPz0D5FngThvtyaAPznLdsZdyhqr7PpnLqEUSnTdWmoqD0hfNU0e

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS "users_storeId_fkey";
ALTER TABLE IF EXISTS ONLY public.transfer_requests DROP CONSTRAINT IF EXISTS "transfer_requests_toStoreId_fkey";
ALTER TABLE IF EXISTS ONLY public.transfer_requests DROP CONSTRAINT IF EXISTS "transfer_requests_fromStoreId_fkey";
ALTER TABLE IF EXISTS ONLY public.transfer_items DROP CONSTRAINT IF EXISTS "transfer_items_transferId_fkey";
ALTER TABLE IF EXISTS ONLY public.transfer_items DROP CONSTRAINT IF EXISTS "transfer_items_deviceId_fkey";
ALTER TABLE IF EXISTS ONLY public.supplier_payments DROP CONSTRAINT IF EXISTS "supplier_payments_supplierId_fkey";
ALTER TABLE IF EXISTS ONLY public.supplier_payment_allocations DROP CONSTRAINT IF EXISTS "supplier_payment_allocations_paymentId_fkey";
ALTER TABLE IF EXISTS ONLY public.supplier_payment_allocations DROP CONSTRAINT IF EXISTS "supplier_payment_allocations_invoiceId_fkey";
ALTER TABLE IF EXISTS ONLY public.supplier_invoices DROP CONSTRAINT IF EXISTS "supplier_invoices_supplierId_fkey";
ALTER TABLE IF EXISTS ONLY public.supplier_invoices DROP CONSTRAINT IF EXISTS "supplier_invoices_storeId_fkey";
ALTER TABLE IF EXISTS ONLY public.supplier_bonuses DROP CONSTRAINT IF EXISTS "supplier_bonuses_supplierId_fkey";
ALTER TABLE IF EXISTS ONLY public.supplier_bonus_devices DROP CONSTRAINT IF EXISTS "supplier_bonus_devices_bonusId_fkey";
ALTER TABLE IF EXISTS ONLY public.store_profit_shares DROP CONSTRAINT IF EXISTS "store_profit_shares_storeId_fkey";
ALTER TABLE IF EXISTS ONLY public.store_profit_shares DROP CONSTRAINT IF EXISTS "store_profit_shares_ownerId_fkey";
ALTER TABLE IF EXISTS ONLY public.sales DROP CONSTRAINT IF EXISTS "sales_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.sales DROP CONSTRAINT IF EXISTS "sales_storeId_fkey";
ALTER TABLE IF EXISTS ONLY public.sales DROP CONSTRAINT IF EXISTS "sales_customerId_fkey";
ALTER TABLE IF EXISTS ONLY public.sale_items DROP CONSTRAINT IF EXISTS "sale_items_saleId_fkey";
ALTER TABLE IF EXISTS ONLY public.sale_items DROP CONSTRAINT IF EXISTS "sale_items_deviceId_fkey";
ALTER TABLE IF EXISTS ONLY public.repair_tickets DROP CONSTRAINT IF EXISTS "repair_tickets_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.repair_tickets DROP CONSTRAINT IF EXISTS "repair_tickets_storeId_fkey";
ALTER TABLE IF EXISTS ONLY public.repair_tickets DROP CONSTRAINT IF EXISTS "repair_tickets_deviceId_fkey";
ALTER TABLE IF EXISTS ONLY public.repair_status_history DROP CONSTRAINT IF EXISTS "repair_status_history_ticketId_fkey";
ALTER TABLE IF EXISTS ONLY public.payroll_payouts DROP CONSTRAINT IF EXISTS payroll_payouts_expense_id_fkey;
ALTER TABLE IF EXISTS ONLY public.payroll_payouts DROP CONSTRAINT IF EXISTS payroll_payouts_employee_id_fkey;
ALTER TABLE IF EXISTS ONLY public.owners DROP CONSTRAINT IF EXISTS "owners_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.owner_transactions DROP CONSTRAINT IF EXISTS "owner_transactions_ownerId_fkey";
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS "notifications_targetUserId_fkey";
ALTER TABLE IF EXISTS ONLY public.invoice_groups DROP CONSTRAINT IF EXISTS "invoice_groups_invoiceId_fkey";
ALTER TABLE IF EXISTS ONLY public.financial_transactions DROP CONSTRAINT IF EXISTS "financial_transactions_shopId_fkey";
ALTER TABLE IF EXISTS ONLY public.financial_transactions DROP CONSTRAINT IF EXISTS "financial_transactions_destinationAccountId_fkey";
ALTER TABLE IF EXISTS ONLY public.financial_transactions DROP CONSTRAINT IF EXISTS "financial_transactions_categoryId_fkey";
ALTER TABLE IF EXISTS ONLY public.financial_transactions DROP CONSTRAINT IF EXISTS "financial_transactions_accountId_fkey";
ALTER TABLE IF EXISTS ONLY public.financial_categories DROP CONSTRAINT IF EXISTS "financial_categories_parentId_fkey";
ALTER TABLE IF EXISTS ONLY public.financial_accounts DROP CONSTRAINT IF EXISTS "financial_accounts_storeId_fkey";
ALTER TABLE IF EXISTS ONLY public.expenses DROP CONSTRAINT IF EXISTS "expenses_storeId_fkey";
ALTER TABLE IF EXISTS ONLY public.exchange_events DROP CONSTRAINT IF EXISTS "exchange_events_saleId_fkey";
ALTER TABLE IF EXISTS ONLY public.devices DROP CONSTRAINT IF EXISTS "devices_supplierId_fkey";
ALTER TABLE IF EXISTS ONLY public.devices DROP CONSTRAINT IF EXISTS "devices_storeId_fkey";
ALTER TABLE IF EXISTS ONLY public.devices DROP CONSTRAINT IF EXISTS "devices_purchaseInvoiceId_fkey";
ALTER TABLE IF EXISTS ONLY public.device_timeline_events DROP CONSTRAINT IF EXISTS "device_timeline_events_deviceId_fkey";
ALTER TABLE IF EXISTS ONLY public.device_identifiers DROP CONSTRAINT IF EXISTS device_identifiers_device_id_fkey;
ALTER TABLE IF EXISTS ONLY public.customer_payments DROP CONSTRAINT IF EXISTS "customer_payments_customerId_fkey";
ALTER TABLE IF EXISTS ONLY public.customer_payment_allocations DROP CONSTRAINT IF EXISTS "customer_payment_allocations_saleId_fkey";
ALTER TABLE IF EXISTS ONLY public.customer_payment_allocations DROP CONSTRAINT IF EXISTS "customer_payment_allocations_paymentId_fkey";
ALTER TABLE IF EXISTS ONLY public.cash_handovers DROP CONSTRAINT IF EXISTS "cash_handovers_storeId_fkey";
ALTER TABLE IF EXISTS ONLY public.bonus_pool_entries DROP CONSTRAINT IF EXISTS "bonus_pool_entries_saleId_fkey";
ALTER TABLE IF EXISTS ONLY public.bonus_pool_entries DROP CONSTRAINT IF EXISTS "bonus_pool_entries_deviceId_fkey";
ALTER TABLE IF EXISTS ONLY public.auth_sessions DROP CONSTRAINT IF EXISTS "auth_sessions_userId_fkey";
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS "audit_logs_userId_fkey";
DROP TRIGGER IF EXISTS device_identifiers_sync ON public.devices;
DROP INDEX IF EXISTS public.users_login_key;
DROP INDEX IF EXISTS public."transfer_requests_transferNumber_key";
DROP INDEX IF EXISTS public."transfer_requests_toStoreId_idx";
DROP INDEX IF EXISTS public."transfer_requests_fromStoreId_idx";
DROP INDEX IF EXISTS public."transfer_items_transferId_idx";
DROP INDEX IF EXISTS public."transfer_items_deviceId_idx";
DROP INDEX IF EXISTS public."supplier_invoices_supplierId_idx";
DROP INDEX IF EXISTS public."supplier_invoices_storeId_idx";
DROP INDEX IF EXISTS public.supplier_invoices_date_idx;
DROP INDEX IF EXISTS public."store_profit_shares_storeId_ownerId_key";
DROP INDEX IF EXISTS public."store_profit_shares_storeId_idx";
DROP INDEX IF EXISTS public."sales_userId_createdAt_idx";
DROP INDEX IF EXISTS public."sales_storeId_createdAt_idx";
DROP INDEX IF EXISTS public."sales_receiptNumber_key";
DROP INDEX IF EXISTS public."sales_customerId_idx";
DROP INDEX IF EXISTS public."sales_createdAt_idx";
DROP INDEX IF EXISTS public."sale_items_saleId_idx";
DROP INDEX IF EXISTS public."sale_items_deviceId_idx";
DROP INDEX IF EXISTS public."repair_tickets_ticketNumber_key";
DROP INDEX IF EXISTS public."repair_tickets_storeId_status_idx";
DROP INDEX IF EXISTS public."repair_tickets_storeId_createdAt_idx";
DROP INDEX IF EXISTS public.payroll_payouts_employee_month_idx;
DROP INDEX IF EXISTS public."owners_userId_key";
DROP INDEX IF EXISTS public."owner_transactions_ownerId_createdAt_idx";
DROP INDEX IF EXISTS public."notifications_targetUserId_read_idx";
DROP INDEX IF EXISTS public."notifications_targetUserId_createdAt_idx";
DROP INDEX IF EXISTS public."notifications_targetRole_read_idx";
DROP INDEX IF EXISTS public."notifications_targetRole_createdAt_idx";
DROP INDEX IF EXISTS public."ledger_entries_createdAt_idx";
DROP INDEX IF EXISTS public."invoice_groups_invoiceId_idx";
DROP INDEX IF EXISTS public."financial_transactions_transactionNumber_key";
DROP INDEX IF EXISTS public."financial_transactions_transactionDate_idx";
DROP INDEX IF EXISTS public.financial_transactions_status_idx;
DROP INDEX IF EXISTS public."financial_transactions_sourceType_sourceId_idx";
DROP INDEX IF EXISTS public."financial_transactions_shopId_idx";
DROP INDEX IF EXISTS public."financial_transactions_reversedTransactionId_key";
DROP INDEX IF EXISTS public."financial_transactions_idempotencyKey_key";
DROP INDEX IF EXISTS public."financial_transactions_counterpartyType_counterpartyId_idx";
DROP INDEX IF EXISTS public."financial_transactions_categoryId_idx";
DROP INDEX IF EXISTS public."financial_transactions_accountId_idx";
DROP INDEX IF EXISTS public."financial_accounts_storeId_key";
DROP INDEX IF EXISTS public."expenses_storeId_createdAt_idx";
DROP INDEX IF EXISTS public."expenses_employeeId_idx";
DROP INDEX IF EXISTS public."expenses_createdAt_idx";
DROP INDEX IF EXISTS public.exchange_rates_date_key;
DROP INDEX IF EXISTS public."devices_supplierId_idx";
DROP INDEX IF EXISTS public."devices_storeId_status_idx";
DROP INDEX IF EXISTS public.devices_status_idx;
DROP INDEX IF EXISTS public."devices_purchaseInvoiceId_idx";
DROP INDEX IF EXISTS public.devices_imei_key;
DROP INDEX IF EXISTS public.devices_imei_idx;
DROP INDEX IF EXISTS public.devices_imei2_key;
DROP INDEX IF EXISTS public."devices_createdAt_idx";
DROP INDEX IF EXISTS public."device_timeline_events_deviceId_idx";
DROP INDEX IF EXISTS public.device_identifiers_device_idx;
DROP INDEX IF EXISTS public.customers_phone_key;
DROP INDEX IF EXISTS public."customer_payments_customerId_idx";
DROP INDEX IF EXISTS public."customer_payment_allocations_saleId_idx";
DROP INDEX IF EXISTS public."customer_payment_allocations_paymentId_idx";
DROP INDEX IF EXISTS public."cash_handovers_storeId_createdAt_idx";
DROP INDEX IF EXISTS public."cash_handovers_financialTransactionId_key";
DROP INDEX IF EXISTS public."cash_handovers_businessDate_idx";
DROP INDEX IF EXISTS public.bonus_pool_entries_status_idx;
DROP INDEX IF EXISTS public."bonus_pool_entries_createdAt_idx";
DROP INDEX IF EXISTS public."bonus_distribution_logs_createdAt_idx";
DROP INDEX IF EXISTS public."auth_sessions_userId_idx";
DROP INDEX IF EXISTS public."audit_logs_targetId_idx";
DROP INDEX IF EXISTS public."audit_logs_createdAt_idx";
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.transfer_requests DROP CONSTRAINT IF EXISTS transfer_requests_pkey;
ALTER TABLE IF EXISTS ONLY public.transfer_items DROP CONSTRAINT IF EXISTS transfer_items_pkey;
ALTER TABLE IF EXISTS ONLY public.suppliers DROP CONSTRAINT IF EXISTS suppliers_pkey;
ALTER TABLE IF EXISTS ONLY public.supplier_payments DROP CONSTRAINT IF EXISTS supplier_payments_pkey;
ALTER TABLE IF EXISTS ONLY public.supplier_payment_allocations DROP CONSTRAINT IF EXISTS supplier_payment_allocations_pkey;
ALTER TABLE IF EXISTS ONLY public.supplier_invoices DROP CONSTRAINT IF EXISTS supplier_invoices_pkey;
ALTER TABLE IF EXISTS ONLY public.supplier_bonuses DROP CONSTRAINT IF EXISTS supplier_bonuses_pkey;
ALTER TABLE IF EXISTS ONLY public.supplier_bonus_devices DROP CONSTRAINT IF EXISTS supplier_bonus_devices_pkey;
ALTER TABLE IF EXISTS ONLY public.stores DROP CONSTRAINT IF EXISTS stores_pkey;
ALTER TABLE IF EXISTS ONLY public.store_profit_shares DROP CONSTRAINT IF EXISTS store_profit_shares_pkey;
ALTER TABLE IF EXISTS ONLY public.sales DROP CONSTRAINT IF EXISTS sales_pkey;
ALTER TABLE IF EXISTS ONLY public.sale_items DROP CONSTRAINT IF EXISTS sale_items_pkey;
ALTER TABLE IF EXISTS ONLY public.repair_tickets DROP CONSTRAINT IF EXISTS repair_tickets_pkey;
ALTER TABLE IF EXISTS ONLY public.repair_status_history DROP CONSTRAINT IF EXISTS repair_status_history_pkey;
ALTER TABLE IF EXISTS ONLY public.quarter_closures DROP CONSTRAINT IF EXISTS quarter_closures_pkey;
ALTER TABLE IF EXISTS ONLY public.payroll_payouts DROP CONSTRAINT IF EXISTS payroll_payouts_pkey;
ALTER TABLE IF EXISTS ONLY public.owners DROP CONSTRAINT IF EXISTS owners_pkey;
ALTER TABLE IF EXISTS ONLY public.owner_transactions DROP CONSTRAINT IF EXISTS owner_transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.operation_requests DROP CONSTRAINT IF EXISTS operation_requests_pkey;
ALTER TABLE IF EXISTS ONLY public.notifications DROP CONSTRAINT IF EXISTS notifications_pkey;
ALTER TABLE IF EXISTS ONLY public.ledger_entries DROP CONSTRAINT IF EXISTS ledger_entries_pkey;
ALTER TABLE IF EXISTS ONLY public.invoice_groups DROP CONSTRAINT IF EXISTS invoice_groups_pkey;
ALTER TABLE IF EXISTS ONLY public.financial_transactions DROP CONSTRAINT IF EXISTS financial_transactions_pkey;
ALTER TABLE IF EXISTS ONLY public.financial_categories DROP CONSTRAINT IF EXISTS financial_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.financial_accounts DROP CONSTRAINT IF EXISTS financial_accounts_pkey;
ALTER TABLE IF EXISTS ONLY public.expenses DROP CONSTRAINT IF EXISTS expenses_pkey;
ALTER TABLE IF EXISTS ONLY public.exchange_rates DROP CONSTRAINT IF EXISTS exchange_rates_pkey;
ALTER TABLE IF EXISTS ONLY public.exchange_events DROP CONSTRAINT IF EXISTS exchange_events_pkey;
ALTER TABLE IF EXISTS ONLY public.document_sequences DROP CONSTRAINT IF EXISTS document_sequences_pkey;
ALTER TABLE IF EXISTS ONLY public.devices DROP CONSTRAINT IF EXISTS devices_pkey;
ALTER TABLE IF EXISTS ONLY public.device_timeline_events DROP CONSTRAINT IF EXISTS device_timeline_events_pkey;
ALTER TABLE IF EXISTS ONLY public.device_identifiers DROP CONSTRAINT IF EXISTS device_identifiers_pkey;
ALTER TABLE IF EXISTS ONLY public.customers DROP CONSTRAINT IF EXISTS customers_pkey;
ALTER TABLE IF EXISTS ONLY public.customer_payments DROP CONSTRAINT IF EXISTS customer_payments_pkey;
ALTER TABLE IF EXISTS ONLY public.customer_payment_allocations DROP CONSTRAINT IF EXISTS customer_payment_allocations_pkey;
ALTER TABLE IF EXISTS ONLY public.cash_handovers DROP CONSTRAINT IF EXISTS cash_handovers_pkey;
ALTER TABLE IF EXISTS ONLY public.bonus_pool_entries DROP CONSTRAINT IF EXISTS bonus_pool_entries_pkey;
ALTER TABLE IF EXISTS ONLY public.bonus_distribution_logs DROP CONSTRAINT IF EXISTS bonus_distribution_logs_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_sessions DROP CONSTRAINT IF EXISTS auth_sessions_pkey;
ALTER TABLE IF EXISTS ONLY public.audit_logs DROP CONSTRAINT IF EXISTS audit_logs_pkey;
ALTER TABLE IF EXISTS ONLY public._prisma_migrations DROP CONSTRAINT IF EXISTS _prisma_migrations_pkey;
ALTER TABLE IF EXISTS public.sales ALTER COLUMN "receiptNumber" DROP DEFAULT;
ALTER TABLE IF EXISTS public.repair_tickets ALTER COLUMN "ticketNumber" DROP DEFAULT;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.transfer_requests;
DROP TABLE IF EXISTS public.transfer_items;
DROP TABLE IF EXISTS public.suppliers;
DROP TABLE IF EXISTS public.supplier_payments;
DROP TABLE IF EXISTS public.supplier_payment_allocations;
DROP TABLE IF EXISTS public.supplier_invoices;
DROP TABLE IF EXISTS public.supplier_bonuses;
DROP TABLE IF EXISTS public.supplier_bonus_devices;
DROP TABLE IF EXISTS public.stores;
DROP TABLE IF EXISTS public.store_profit_shares;
DROP SEQUENCE IF EXISTS public."sales_receiptNumber_seq";
DROP TABLE IF EXISTS public.sales;
DROP TABLE IF EXISTS public.sale_items;
DROP SEQUENCE IF EXISTS public."repair_tickets_ticketNumber_seq";
DROP TABLE IF EXISTS public.repair_tickets;
DROP TABLE IF EXISTS public.repair_status_history;
DROP TABLE IF EXISTS public.quarter_closures;
DROP TABLE IF EXISTS public.payroll_payouts;
DROP TABLE IF EXISTS public.owners;
DROP TABLE IF EXISTS public.owner_transactions;
DROP TABLE IF EXISTS public.operation_requests;
DROP TABLE IF EXISTS public.notifications;
DROP TABLE IF EXISTS public.ledger_entries;
DROP TABLE IF EXISTS public.invoice_groups;
DROP TABLE IF EXISTS public.financial_transactions;
DROP TABLE IF EXISTS public.financial_categories;
DROP TABLE IF EXISTS public.financial_accounts;
DROP TABLE IF EXISTS public.expenses;
DROP TABLE IF EXISTS public.exchange_rates;
DROP TABLE IF EXISTS public.exchange_events;
DROP TABLE IF EXISTS public.document_sequences;
DROP TABLE IF EXISTS public.devices;
DROP TABLE IF EXISTS public.device_timeline_events;
DROP TABLE IF EXISTS public.device_identifiers;
DROP TABLE IF EXISTS public.customers;
DROP TABLE IF EXISTS public.customer_payments;
DROP TABLE IF EXISTS public.customer_payment_allocations;
DROP TABLE IF EXISTS public.cash_handovers;
DROP TABLE IF EXISTS public.bonus_pool_entries;
DROP TABLE IF EXISTS public.bonus_distribution_logs;
DROP TABLE IF EXISTS public.auth_sessions;
DROP TABLE IF EXISTS public.audit_logs;
DROP TABLE IF EXISTS public._prisma_migrations;
DROP FUNCTION IF EXISTS public.sync_device_identifiers();
DROP TYPE IF EXISTS public."TransferStatus";
DROP TYPE IF EXISTS public."SaleStatus";
DROP TYPE IF EXISTS public."Role";
DROP TYPE IF EXISTS public."RepairStatus";
DROP TYPE IF EXISTS public."PaymentMethod";
DROP TYPE IF EXISTS public."OwnerTransactionType";
DROP TYPE IF EXISTS public."LedgerType";
DROP TYPE IF EXISTS public."LedgerCurrency";
DROP TYPE IF EXISTS public."FinancialTransactionType";
DROP TYPE IF EXISTS public."FinancialTransactionStatus";
DROP TYPE IF EXISTS public."FinancialDirection";
DROP TYPE IF EXISTS public."FinancialAccountType";
DROP TYPE IF EXISTS public."DeviceStatus";
DROP TYPE IF EXISTS public."CounterpartyType";
DROP TYPE IF EXISTS public."BonusType";
DROP TYPE IF EXISTS public."BonusPoolStatus";
DROP SCHEMA IF EXISTS public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: BonusPoolStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."BonusPoolStatus" AS ENUM (
    'PENDING',
    'DISTRIBUTED',
    'ANNULLED'
);


--
-- Name: BonusType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."BonusType" AS ENUM (
    'FREE_DEVICES',
    'CASH_DISCOUNT'
);


--
-- Name: CounterpartyType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."CounterpartyType" AS ENUM (
    'SUPPLIER',
    'CUSTOMER',
    'EMPLOYEE',
    'OWNER',
    'OTHER'
);


--
-- Name: DeviceStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."DeviceStatus" AS ENUM (
    'MAIN_WAREHOUSE',
    'STORE_STOCK',
    'SOLD',
    'IN_STOCK_AFTER_EXCHANGE',
    'IN_REPAIR',
    'TRANSFER_PENDING'
);


--
-- Name: FinancialAccountType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."FinancialAccountType" AS ENUM (
    'CASH',
    'BANK',
    'MAIN',
    'OTHER'
);


--
-- Name: FinancialDirection; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."FinancialDirection" AS ENUM (
    'IN',
    'OUT',
    'NEUTRAL'
);


--
-- Name: FinancialTransactionStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."FinancialTransactionStatus" AS ENUM (
    'POSTED',
    'CANCELLED'
);


--
-- Name: FinancialTransactionType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."FinancialTransactionType" AS ENUM (
    'INCOME',
    'EXPENSE',
    'TRANSFER',
    'SUPPLIER_PAYMENT',
    'OWNER_DEPOSIT',
    'OWNER_WITHDRAWAL',
    'REFUND',
    'ADJUSTMENT'
);


--
-- Name: LedgerCurrency; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."LedgerCurrency" AS ENUM (
    'TJS',
    'USD'
);


--
-- Name: LedgerType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."LedgerType" AS ENUM (
    'SALE',
    'CASH_SALE',
    'CARD_SALE',
    'PURCHASE',
    'EXPENSE',
    'SALARY',
    'SUPPLIER_PAYMENT',
    'OWNER_INVESTMENT',
    'OWNER_CAPITAL_WITHDRAWAL',
    'OWNER_PROFIT_PAYOUT',
    'OWNER_REINVESTMENT',
    'EXCHANGE_SETTLEMENT',
    'SUPPLIER_BONUS',
    'TRANSFER',
    'REFUND',
    'CUSTOMER_PAYMENT'
);


--
-- Name: OwnerTransactionType; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."OwnerTransactionType" AS ENUM (
    'INVESTMENT',
    'WITHDRAWAL',
    'PROFIT_PAYOUT',
    'REINVEST'
);


--
-- Name: PaymentMethod; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."PaymentMethod" AS ENUM (
    'CASH',
    'CARD',
    'SPLIT',
    'DEBT'
);


--
-- Name: RepairStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."RepairStatus" AS ENUM (
    'ACCEPTED',
    'IN_PROGRESS',
    'READY',
    'ISSUED',
    'DIAGNOSTICS',
    'IN_REPAIR',
    'DELIVERED',
    'UNREPAIRABLE'
);


--
-- Name: Role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."Role" AS ENUM (
    'ADMIN',
    'PARTNER',
    'SELLER'
);


--
-- Name: SaleStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."SaleStatus" AS ENUM (
    'COMPLETED',
    'EXCHANGED',
    'REFUNDED'
);


--
-- Name: TransferStatus; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public."TransferStatus" AS ENUM (
    'PENDING_APPROVAL',
    'APPROVED',
    'REJECTED'
);


--
-- Name: sync_device_identifiers(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sync_device_identifiers() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  DELETE FROM device_identifiers WHERE device_id = NEW.id;
  INSERT INTO device_identifiers(identifier, device_id) VALUES (NEW.imei, NEW.id);
  IF NEW.imei2 IS NOT NULL THEN
    INSERT INTO device_identifiers(identifier, device_id) VALUES (NEW.imei2, NEW.id);
  END IF;
  RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: _prisma_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._prisma_migrations (
    id character varying(36) NOT NULL,
    checksum character varying(64) NOT NULL,
    finished_at timestamp with time zone,
    migration_name character varying(255) NOT NULL,
    logs text,
    rolled_back_at timestamp with time zone,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    applied_steps_count integer DEFAULT 0 NOT NULL
);


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id text NOT NULL,
    "userId" text,
    "userName" text,
    "userRole" text,
    "storeName" text,
    action text NOT NULL,
    details text NOT NULL,
    "financialDetails" jsonb,
    imei text,
    "receiptNumber" integer,
    "targetId" text,
    "ipAddress" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: auth_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_sessions (
    id text NOT NULL,
    "userId" text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "revokedAt" timestamp(3) without time zone
);


--
-- Name: bonus_distribution_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bonus_distribution_logs (
    id text NOT NULL,
    "periodName" text NOT NULL,
    "totalAmountUsd" numeric(14,2) NOT NULL,
    "totalAmountTjs" numeric(14,2),
    type text NOT NULL,
    allocations jsonb NOT NULL,
    note text,
    "performedByUserId" text NOT NULL,
    "performedByName" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: bonus_pool_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bonus_pool_entries (
    id text NOT NULL,
    "deviceId" text NOT NULL,
    "saleId" text,
    "saleItemId" text,
    imei text NOT NULL,
    brand text NOT NULL,
    model text NOT NULL,
    "salePriceUsd" numeric(14,2) NOT NULL,
    "salePriceTjs" numeric(14,2) NOT NULL,
    "profitUsd" numeric(14,2) NOT NULL,
    "profitTjs" numeric(14,2) NOT NULL,
    status public."BonusPoolStatus" DEFAULT 'PENDING'::public."BonusPoolStatus" NOT NULL,
    "distributionId" text,
    "distributedAt" timestamp(3) without time zone,
    "distributedBy" text,
    "distributionNote" text,
    "annulledAt" timestamp(3) without time zone,
    "annulledBy" text,
    "annulledNote" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: cash_handovers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cash_handovers (
    id text NOT NULL,
    "storeId" text NOT NULL,
    "amountTjs" numeric(14,2) NOT NULL,
    "exchangeRate" numeric(10,4) NOT NULL,
    "amountUsd" numeric(14,2) NOT NULL,
    "businessDate" text NOT NULL,
    "acceptedByUserId" text NOT NULL,
    "acceptedByName" text NOT NULL,
    "financialTransactionId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: customer_payment_allocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_payment_allocations (
    id text NOT NULL,
    "paymentId" text NOT NULL,
    "saleId" text NOT NULL,
    "allocatedAmountTjs" numeric(14,2) NOT NULL
);


--
-- Name: customer_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customer_payments (
    id text NOT NULL,
    "customerId" text NOT NULL,
    "amountTjs" numeric(14,2) NOT NULL,
    "sourceAccount" text NOT NULL,
    "storeId" text,
    "createdByUserId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "exchangeRate" numeric(10,4) NOT NULL
);


--
-- Name: customers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.customers (
    id text NOT NULL,
    name text NOT NULL,
    phone text,
    "totalDebtTjs" numeric(14,2) DEFAULT 0 NOT NULL,
    "totalPaidTjs" numeric(14,2) DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: device_identifiers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_identifiers (
    identifier text NOT NULL,
    device_id text NOT NULL
);


--
-- Name: device_timeline_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_timeline_events (
    id text NOT NULL,
    "deviceId" text NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    type text NOT NULL,
    description text NOT NULL,
    "userName" text NOT NULL,
    "storeName" text,
    "priceTjs" numeric(14,2),
    "priceUsd" numeric(14,2)
);


--
-- Name: devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.devices (
    id text NOT NULL,
    imei text NOT NULL,
    imei2 text,
    brand text NOT NULL,
    model text NOT NULL,
    storage text NOT NULL,
    color text NOT NULL,
    status public."DeviceStatus" DEFAULT 'MAIN_WAREHOUSE'::public."DeviceStatus" NOT NULL,
    "storeId" text NOT NULL,
    "purchasePriceUsd" numeric(14,2) NOT NULL,
    "costBasisUsd" numeric(14,2) NOT NULL,
    "retailPriceTjs" numeric(14,2),
    "receivedDate" timestamp(3) without time zone,
    "isBonus" boolean DEFAULT false NOT NULL,
    "bonusCampaign" text,
    "supplierId" text,
    "supplierName" text,
    "invoiceNumber" text,
    "purchaseInvoiceId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    ram text
);


--
-- Name: document_sequences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_sequences (
    key text NOT NULL,
    "nextValue" integer DEFAULT 1 NOT NULL
);


--
-- Name: exchange_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.exchange_events (
    id text NOT NULL,
    "saleId" text NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "returnedDeviceId" text NOT NULL,
    "returnedImei" text NOT NULL,
    "returnedModel" text NOT NULL,
    "exchangeInValueTjs" numeric(14,2) NOT NULL,
    "exchangeInValueUsd" numeric(14,2) NOT NULL,
    "replacementDeviceId" text NOT NULL,
    "replacementImei" text NOT NULL,
    "replacementModel" text NOT NULL,
    "newPriceTjs" numeric(14,2) NOT NULL,
    "newPriceUsd" numeric(14,2) NOT NULL,
    "differenceTjs" numeric(14,2) NOT NULL,
    "paymentMethod" public."PaymentMethod",
    "cashAmountTjs" numeric(14,2),
    "cardAmountTjs" numeric(14,2),
    "processedByUserId" text NOT NULL,
    "exchangeRate" numeric(10,4) NOT NULL
);


--
-- Name: exchange_rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.exchange_rates (
    id text NOT NULL,
    date text NOT NULL,
    rate numeric(10,4) NOT NULL,
    "createdByUserId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedByUserId" text,
    "updatedAt" timestamp(3) without time zone
);


--
-- Name: expenses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.expenses (
    id text NOT NULL,
    category text NOT NULL,
    "amountTjs" numeric(14,2) NOT NULL,
    "amountUsd" numeric(14,2),
    "exchangeRate" numeric(10,4),
    "targetType" text DEFAULT 'STORE'::text NOT NULL,
    "storeId" text,
    "sourceAccount" text,
    comment text,
    description text,
    "createdByUserId" text NOT NULL,
    "paidFromCashRegister" boolean DEFAULT true NOT NULL,
    "employeeId" text,
    "isEmployeeAdvance" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "cancelledAt" timestamp(3) without time zone,
    "cancelledByUserId" text,
    "ownerProfitAllocations" jsonb,
    status text DEFAULT 'PAID'::text NOT NULL,
    "paidAt" timestamp(3) without time zone,
    "payrollMonth" text
);


--
-- Name: financial_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.financial_accounts (
    id text NOT NULL,
    name text NOT NULL,
    type public."FinancialAccountType" NOT NULL,
    "storeId" text,
    active boolean DEFAULT true NOT NULL,
    "openingBalanceTjs" numeric(14,2) DEFAULT 0 NOT NULL,
    "openingBalanceUsd" numeric(14,2) DEFAULT 0 NOT NULL,
    "balanceTjs" numeric(14,2) DEFAULT 0 NOT NULL,
    "balanceUsd" numeric(14,2) DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: financial_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.financial_categories (
    id text NOT NULL,
    name text NOT NULL,
    direction public."FinancialDirection" NOT NULL,
    "parentId" text,
    "isSystem" boolean DEFAULT false NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: financial_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.financial_transactions (
    id text NOT NULL,
    "transactionNumber" text NOT NULL,
    type public."FinancialTransactionType" NOT NULL,
    direction public."FinancialDirection" NOT NULL,
    status public."FinancialTransactionStatus" DEFAULT 'POSTED'::public."FinancialTransactionStatus" NOT NULL,
    "transactionDate" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "accountId" text NOT NULL,
    "destinationAccountId" text,
    amount numeric(14,2) NOT NULL,
    currency text NOT NULL,
    "exchangeRate" numeric(10,4),
    "amountTjs" numeric(14,2) NOT NULL,
    "amountUsd" numeric(14,2) NOT NULL,
    "categoryId" text,
    "counterpartyType" public."CounterpartyType",
    "counterpartyId" text,
    "counterpartyName" text,
    "shopId" text,
    "sourceType" text,
    "sourceId" text,
    "reversedTransactionId" text,
    description text NOT NULL,
    comment text,
    "createdByUserId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "cancelledAt" timestamp(3) without time zone,
    "cancelledByUserId" text,
    "balanceCurrency" public."LedgerCurrency" NOT NULL,
    "idempotencyKey" text
);


--
-- Name: invoice_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_groups (
    id text NOT NULL,
    "invoiceId" text NOT NULL,
    brand text NOT NULL,
    model text NOT NULL,
    storage text NOT NULL,
    color text NOT NULL,
    quantity integer NOT NULL,
    "purchasePriceUsd" numeric(14,2) NOT NULL,
    ram text
);


--
-- Name: ledger_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ledger_entries (
    id text NOT NULL,
    type public."LedgerType" NOT NULL,
    description text NOT NULL,
    "amountTjs" numeric(14,2),
    "amountUsd" numeric(14,2),
    "exchangeRate" numeric(10,4),
    "storeId" text,
    "storeName" text,
    "userName" text,
    "referenceId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id text NOT NULL,
    title text NOT NULL,
    message text NOT NULL,
    "targetType" text,
    "targetId" text,
    "targetRoute" text,
    "targetRole" public."Role",
    "targetUserId" text,
    read boolean DEFAULT false NOT NULL,
    resolved boolean DEFAULT false NOT NULL,
    "readAt" timestamp(3) without time zone,
    "resolvedAt" timestamp(3) without time zone,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: operation_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.operation_requests (
    key text NOT NULL,
    fingerprint text NOT NULL,
    result jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: owner_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.owner_transactions (
    id text NOT NULL,
    "ownerId" text NOT NULL,
    type public."OwnerTransactionType" NOT NULL,
    "amountUsd" numeric(14,2) NOT NULL,
    "sourceOrDestination" text,
    "createdByUserId" text NOT NULL,
    note text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "exchangeRate" numeric(10,4) NOT NULL
);


--
-- Name: owners; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.owners (
    id text NOT NULL,
    name text NOT NULL,
    "profitSharePercent" numeric(7,4) NOT NULL,
    "capitalBalanceUsd" numeric(14,2) DEFAULT 0 NOT NULL,
    "totalAccruedProfitUsd" numeric(14,2) DEFAULT 0 NOT NULL,
    "totalPaidProfitUsd" numeric(14,2) DEFAULT 0 NOT NULL,
    "totalReinvestedUsd" numeric(14,2) DEFAULT 0 NOT NULL,
    "availableProfitUsd" numeric(14,2) DEFAULT 0 NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "userId" text,
    "storeId" text
);


--
-- Name: payroll_payouts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payroll_payouts (
    expense_id text NOT NULL,
    employee_id text NOT NULL,
    month text NOT NULL,
    gross_tjs numeric(14,2) NOT NULL,
    previous_salary_tjs numeric(14,2) NOT NULL,
    paid_advances_tjs numeric(14,2) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT payroll_payouts_gross_tjs_check CHECK ((gross_tjs > (0)::numeric)),
    CONSTRAINT payroll_payouts_month_check CHECK ((month ~ '^[0-9]{4}-(0[1-9]|1[0-2])$'::text))
);


--
-- Name: quarter_closures; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.quarter_closures (
    id text NOT NULL,
    "quarterName" text NOT NULL,
    "closedByUserId" text NOT NULL,
    snapshot jsonb NOT NULL,
    "closedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: repair_status_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repair_status_history (
    id text NOT NULL,
    "ticketId" text NOT NULL,
    status public."RepairStatus" NOT NULL,
    "updatedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedByUserId" text NOT NULL,
    note text
);


--
-- Name: repair_tickets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repair_tickets (
    id text NOT NULL,
    "ticketNumber" integer NOT NULL,
    "storeId" text NOT NULL,
    "userId" text NOT NULL,
    "deviceId" text,
    imei text NOT NULL,
    imei2 text,
    brand text NOT NULL,
    model text NOT NULL,
    storage text,
    color text,
    "saleReceiptNumber" integer,
    "saleDate" timestamp(3) without time zone,
    "customerName" text,
    "customerPhone" text,
    "prepaymentTjs" numeric(14,2),
    "problemDescription" text NOT NULL,
    "visualCondition" text,
    "equipmentPackage" text,
    comment text,
    status public."RepairStatus" DEFAULT 'ACCEPTED'::public."RepairStatus" NOT NULL,
    "estimatedCostTjs" numeric(14,2),
    "finalCostTjs" numeric(14,2),
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "estimatedCostUsd" numeric(14,2),
    "exchangeRate" numeric(10,4),
    "finalCostUsd" numeric(14,2)
);


--
-- Name: repair_tickets_ticketNumber_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."repair_tickets_ticketNumber_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: repair_tickets_ticketNumber_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."repair_tickets_ticketNumber_seq" OWNED BY public.repair_tickets."ticketNumber";


--
-- Name: sale_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sale_items (
    id text NOT NULL,
    "saleId" text NOT NULL,
    "deviceId" text NOT NULL,
    brand text NOT NULL,
    model text NOT NULL,
    storage text NOT NULL,
    color text NOT NULL,
    imei text NOT NULL,
    imei2 text,
    "salePriceTjs" numeric(14,2) NOT NULL,
    "salePriceUsd" numeric(14,2) NOT NULL,
    "purchaseCostUsd" numeric(14,2) NOT NULL,
    "costBasisUsd" numeric(14,2) NOT NULL,
    "isBelowCost" boolean DEFAULT false NOT NULL,
    "isBonus" boolean DEFAULT false NOT NULL
);


--
-- Name: sales; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sales (
    id text NOT NULL,
    "receiptNumber" integer NOT NULL,
    "storeId" text NOT NULL,
    "userId" text NOT NULL,
    "customerName" text,
    "totalTjs" numeric(14,2) NOT NULL,
    "totalUsd" numeric(14,2) NOT NULL,
    "exchangeRate" numeric(10,4),
    "paymentMethod" public."PaymentMethod" NOT NULL,
    "cashAmountTjs" numeric(14,2) DEFAULT 0 NOT NULL,
    "cardAmountTjs" numeric(14,2) DEFAULT 0 NOT NULL,
    "exchangeTradeInCreditTjs" numeric(14,2),
    status public."SaleStatus" DEFAULT 'COMPLETED'::public."SaleStatus" NOT NULL,
    "hasBelowCostItem" boolean DEFAULT false NOT NULL,
    "refundReason" text,
    "refundedAt" timestamp(3) without time zone,
    "refundedByUserId" text,
    "penaltyFeeTjs" numeric(14,2),
    "penaltyFeeUsd" numeric(14,2),
    "actualRefundAmountTjs" numeric(14,2),
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "customerId" text,
    "debtAmountTjs" numeric(14,2) DEFAULT 0 NOT NULL
);


--
-- Name: sales_receiptNumber_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public."sales_receiptNumber_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sales_receiptNumber_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public."sales_receiptNumber_seq" OWNED BY public.sales."receiptNumber";


--
-- Name: store_profit_shares; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.store_profit_shares (
    id text NOT NULL,
    "storeId" text NOT NULL,
    "ownerId" text NOT NULL,
    "sharePercent" numeric(7,4) NOT NULL,
    "updatedByUserId" text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: stores; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.stores (
    id text NOT NULL,
    name text NOT NULL,
    address text,
    "isMainWarehouse" boolean DEFAULT false NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL,
    "cashBalanceUsd" numeric(14,2) DEFAULT 0 NOT NULL
);


--
-- Name: supplier_bonus_devices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplier_bonus_devices (
    id text NOT NULL,
    "bonusId" text NOT NULL,
    "deviceId" text,
    brand text NOT NULL,
    model text NOT NULL,
    storage text NOT NULL,
    color text NOT NULL,
    imei text NOT NULL,
    "costBasisUsd" numeric(14,2) NOT NULL
);


--
-- Name: supplier_bonuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplier_bonuses (
    id text NOT NULL,
    "supplierId" text NOT NULL,
    "campaignTitle" text,
    "bonusType" public."BonusType" NOT NULL,
    "amountUsd" numeric(14,2),
    status text,
    "dateReceived" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "exchangeRate" numeric(10,4) NOT NULL,
    "ownerProfitAllocations" jsonb
);


--
-- Name: supplier_invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplier_invoices (
    id text NOT NULL,
    "invoiceNumber" text NOT NULL,
    "supplierId" text NOT NULL,
    date timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "totalAmountUsd" numeric(14,2) NOT NULL,
    "paidAmountUsd" numeric(14,2) DEFAULT 0 NOT NULL,
    "devicesCount" integer DEFAULT 0 NOT NULL,
    "isStorePurchase" boolean DEFAULT false NOT NULL,
    "storeId" text,
    "exchangeRate" numeric(10,4) NOT NULL
);


--
-- Name: supplier_payment_allocations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplier_payment_allocations (
    id text NOT NULL,
    "paymentId" text NOT NULL,
    "invoiceId" text NOT NULL,
    "allocatedAmountUsd" numeric(14,2) NOT NULL
);


--
-- Name: supplier_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.supplier_payments (
    id text NOT NULL,
    "supplierId" text NOT NULL,
    "amountUsd" numeric(14,2) NOT NULL,
    "sourceAccount" text NOT NULL,
    "storeId" text,
    "createdByUserId" text NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "exchangeRate" numeric(10,4) NOT NULL
);


--
-- Name: suppliers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.suppliers (
    id text NOT NULL,
    name text NOT NULL,
    phone text,
    "contactPerson" text,
    "totalPurchasedUsd" numeric(14,2) DEFAULT 0 NOT NULL,
    "totalPaidUsd" numeric(14,2) DEFAULT 0 NOT NULL,
    "totalDebtUsd" numeric(14,2) DEFAULT 0 NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: transfer_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transfer_items (
    id text NOT NULL,
    "transferId" text NOT NULL,
    "deviceId" text NOT NULL,
    imei text NOT NULL,
    model text NOT NULL,
    brand text NOT NULL
);


--
-- Name: transfer_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transfer_requests (
    id text NOT NULL,
    "transferNumber" text NOT NULL,
    "fromStoreId" text NOT NULL,
    "toStoreId" text NOT NULL,
    status public."TransferStatus" DEFAULT 'PENDING_APPROVAL'::public."TransferStatus" NOT NULL,
    "requestedByUserId" text NOT NULL,
    "requestedAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "approvedByUserId" text,
    "approvedAt" timestamp(3) without time zone,
    "rejectedReason" text,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id text NOT NULL,
    login text NOT NULL,
    password text NOT NULL,
    name text NOT NULL,
    role public."Role" DEFAULT 'SELLER'::public."Role" NOT NULL,
    active boolean DEFAULT true NOT NULL,
    "storeId" text,
    "baseSalaryTjs" numeric(14,2),
    "salesCommissionPercent" numeric(7,4),
    pin text,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


--
-- Name: repair_tickets ticketNumber; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_tickets ALTER COLUMN "ticketNumber" SET DEFAULT nextval('public."repair_tickets_ticketNumber_seq"'::regclass);


--
-- Name: sales receiptNumber; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales ALTER COLUMN "receiptNumber" SET DEFAULT nextval('public."sales_receiptNumber_seq"'::regclass);


--
-- Data for Name: _prisma_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._prisma_migrations (id, checksum, finished_at, migration_name, logs, rolled_back_at, started_at, applied_steps_count) FROM stdin;
35b7e1f5-fa4c-4b96-a2ad-b1909f0b4bcd	b9c9c0fcca43e0df36f6cca56cbbf7b64c1f74e9ba2151a7f064dec27b6458a7	2026-09-17 15:26:43.809317+00	20260909070900_backfill_repair_usd_snapshot	\N	\N	2026-09-17 15:26:43.78827+00	1
8a861dcf-2cda-4a51-86a7-8afad6594669	b7713da001d8187771047dbae4fa8b15c795740495180e50474c69c53ac5184f	2026-09-17 15:26:43.037902+00	20260824235022_align_domain_model	\N	\N	2026-09-17 15:26:42.384419+00	1
d658fbef-877e-4e1e-8a6a-ff8df635e627	9ea15039beaef958cc02d915e8bbf6daab9864b7e46665cfd1568f9417f96966	2026-09-17 15:26:43.051254+00	20260825013023_imei2_unique_constraint	\N	\N	2026-09-17 15:26:43.040187+00	1
97205084-54eb-41cc-9cb4-c836f513c02b	a994facf6d1d4de0bba11999dfb5410c5271f967186e2c38d1076e19bcfd541a	2026-09-17 16:42:40.39552+00	20260917180000_audit_fixes	\N	\N	2026-09-17 16:42:40.351151+00	1
3e437ef3-cc9a-4d3f-a002-d9ccee9c7a34	97e201bdf00d9913c7c9e5d8ff077461f1b62773c13983a8a278283d85d3f454	2026-09-17 15:26:43.100021+00	20260828193133_add_customer_debt_tracking	\N	\N	2026-09-17 15:26:43.053547+00	1
309cda8e-200e-415e-b7ce-6d915149b3e4	fe0775c1d73c05b2080f852b5a78f26ca6fd8a01a11b3a8c76cec53e614b2c65	2026-09-17 15:26:43.83656+00	20260909212516_add_device_supplier_invoice_indexes	\N	\N	2026-09-17 15:26:43.815027+00	1
7c3b2d81-c05c-45e2-80e3-550927008b5f	a707fc2228f97d22fb98708a329f925a46f744430e6e5d34f7905de1b9e6dbcb	2026-09-17 15:26:43.14207+00	20260828212630_add_device_ram_and_perf_indexes	\N	\N	2026-09-17 15:26:43.102296+00	1
13aa8f66-c627-4a16-bb0d-2c66a5b32bf7	5e45f2a861c601140c7e91401347c2e17a51a77e395f4b4d92860c920a34f3cb	2026-09-17 15:26:43.155049+00	20260829110725_link_owner_to_user	\N	\N	2026-09-17 15:26:43.144278+00	1
2d6edc03-703e-4278-982b-6bbc87df140e	3ac34c09dbc8bb32159f2774072a381f95841bfdb97277a120f5b168432830ad	2026-09-17 15:26:43.182555+00	20260829152447_add_performance_indexes	\N	\N	2026-09-17 15:26:43.157146+00	1
16836a08-a3e3-4e98-8981-d3e98b3d6860	e8a2722c3f8dccd3b1a70e237958c9eab04be5ba881ab3de7de51b2c792e9c6f	2026-09-17 15:26:43.860855+00	20260909213751_add_sale_seller_index	\N	\N	2026-09-17 15:26:43.841316+00	1
2e15b210-ac2d-4720-af98-c9dc36f63492	4489b859fba73f96fb59e060b35b98134739e266c426da716e8562ef75dafd69	2026-09-17 15:26:43.196953+00	20260830170000_merge_duplicate_seed_owners	\N	\N	2026-09-17 15:26:43.185353+00	1
0079c34e-4c6e-49bd-bb60-3455a17e0c95	633a81344999b5273a1eceb4e8431c07ed50905d6e447d8293987b09488a9ff2	2026-09-17 15:26:43.210519+00	20260901090000_snapshot_exchange_rate_on_operations	\N	\N	2026-09-17 15:26:43.199046+00	1
7c5ecab1-c443-4fe8-bafe-1183a241cb90	0ab193550e2e77b58384ee437d7b18954906f02c91ba5055ae2355d11d7f753b	2026-09-17 15:26:43.21953+00	20260906214523_drop_device_serial_number	\N	\N	2026-09-17 15:26:43.213241+00	1
bae011e2-1f08-4a24-ae4b-306c84160267	59cd5273306293a3470695bb4858fd31053fa22305e22e1abcf3a574675105b4	2026-09-17 15:26:43.885797+00	20260909215902_add_invoice_date_index	\N	\N	2026-09-17 15:26:43.865637+00	1
78389dfd-cfd9-4272-893c-02bcc7decc6f	ffd279ef511fe6659cdc21679206ef0e0001b2201985b6fa5012daa5a5f2cc4a	2026-09-17 15:26:43.228595+00	20260906220538_add_brand_to_transfer_items	\N	\N	2026-09-17 15:26:43.221537+00	1
d8ca98fd-2b18-40fa-8fe5-d3030a3c6f2b	5943fb09dcf1c33148055ec62807ed3a6ef8dfdfa9eb913918466df22770a5f4	2026-09-17 15:26:43.750653+00	20260908014000_convert_money_fields_to_decimal	\N	\N	2026-09-17 15:26:43.230727+00	1
d9297000-f51a-4e0e-a65b-c575a9fb9958	3cf19e35ac75db093b5ab92b93adbd49bcbb70c4867f39a99eabb452016dca1b	2026-09-25 04:41:28.114147+00	20260925120000_add_expense_payment_status	\N	\N	2026-09-25 04:41:28.062689+00	1
13398e67-f294-4b8f-8c24-3fe52359238e	45fc9d7f69f06d33efd7febe55356e9f02c6aea85cfcb248ce42862891ba889a	2026-09-17 15:26:43.781784+00	20260909070812_add_usd_snapshot_to_repairs	\N	\N	2026-09-17 15:26:43.756672+00	1
bb305603-bce3-4bd4-9f3f-53333d1d38ba	edf26b87acdc433390cee58522cf06438d858653125596643c48e41f134b614a	2026-09-17 15:26:43.908412+00	20260910134327_add_expense_employee_index	\N	\N	2026-09-17 15:26:43.892108+00	1
5fe526b3-d5f6-43d9-9723-cec3076785b1	b4f55dfd71e75f43bc39903cd7df025baba6dcd371c27ce958e1fed2cff5bb06	2026-09-17 15:26:43.992856+00	20260916213327_add_financial_ledger	\N	\N	2026-09-17 15:26:43.913365+00	1
6acdfa6f-8fa3-4cb3-8854-c254942086e7	0a4b63f0dc50630dd6cf41f1177b78f414f19be9d265802c32670bc833761d27	2026-09-25 07:19:27.871305+00	20260925150000_deactivate_main_account	\N	\N	2026-09-25 07:19:27.854123+00	1
694d1aa0-ee99-420b-8bb4-d0739f411ae6	60da763338e2b6b33a956ce6b9285d3e28dfea7c12ac46ef4e02f691c813153f	2026-09-17 15:26:44.00218+00	20260916213832_add_transaction_balance_currency	\N	\N	2026-09-17 15:26:43.995334+00	1
26631ce6-be5d-43ab-a1da-20bae66c13d6	b5a0007ca9218ff275ebeb38a5d9a474b9f67c5b691dba0df4ded3f0a1af6031	2026-09-17 15:26:44.014107+00	20260917150629_add_financial_transaction_idempotency_key	\N	\N	2026-09-17 15:26:44.004442+00	1
bacb4128-005b-49cc-9010-8bc208349989	2a286e75497894b198525c22753f9995a23e52e18d90365422189b06a89b0178	2026-09-29 19:14:13.028914+00	20260930000000_partner_store_and_device_ram	\N	\N	2026-09-29 19:14:13.002437+00	1
d5d28001-8464-489c-a1e3-fe83c2a603af	ba73c5fd6096272700ef5da3650b348253fb706316efdcaa5f9704ec4bb11457	2026-09-28 00:53:13.816106+00	20260925190000_decimal_percentages	\N	\N	2026-09-28 00:53:13.710832+00	1
b06a9b4b-4159-409b-9915-8534228d9f8d	41bd959a7470417761cff8e7e4f4b64b43f80e0604d6838bf8e8b502319077e9	2026-09-28 00:53:13.852063+00	20260926030000_functional_integrity	\N	\N	2026-09-28 00:53:13.818699+00	1
dc989ef0-19f6-421f-86c5-93c329d6716e	e6c36e21f01505c3664d51be5ce7de17e807c6801d292f149fefa43002379a1f	2026-09-28 00:53:13.877803+00	20260926040000_payroll_periods	\N	\N	2026-09-28 00:53:13.85454+00	1
a194b4b3-0f80-440e-a391-c93774404ab2	eb7029f457b2f4c55abfa3882d4f8a54a95b2ac1cd6ad22bb29900fc897c72f6	\N	20260930120000_cash_handovers	A migration failed to apply. New migrations cannot be applied before the error is recovered from. Read more about how to resolve migration issues in a production database: https://pris.ly/d/migrate-resolve\n\nMigration name: 20260930120000_cash_handovers\n\nDatabase error code: 42P07\n\nDatabase error:\nERROR: relation "cash_handovers" already exists\n\nDbError { severity: "ERROR", parsed_severity: Some(Error), code: SqlState(E42P07), message: "relation \\"cash_handovers\\" already exists", detail: None, hint: None, position: None, where_: None, schema: None, table: None, column: None, datatype: None, constraint: None, file: Some("heap.c"), line: Some(1164), routine: Some("heap_create_with_catalog") }\n\n   0: sql_schema_connector::apply_migration::apply_script\n           with migration_name="20260930120000_cash_handovers"\n             at schema-engine\\connectors\\sql-schema-connector\\src\\apply_migration.rs:113\n   1: schema_commands::commands::apply_migrations::Applying migration\n           with migration_name="20260930120000_cash_handovers"\n             at schema-engine\\commands\\src\\commands\\apply_migrations.rs:91\n   2: schema_core::state::ApplyMigrations\n             at schema-engine\\core\\src\\state.rs:236	2026-10-01 04:03:13.98811+00	2026-10-01 04:03:08.608944+00	0
77cc1447-7f09-4a92-9dbe-ea1f0798a118	eb7029f457b2f4c55abfa3882d4f8a54a95b2ac1cd6ad22bb29900fc897c72f6	2026-10-01 04:03:13.995205+00	20260930120000_cash_handovers		\N	2026-10-01 04:03:13.995205+00	0
8280bc14-04e2-4426-aed2-ab2ebcdcc4fe	24dcf0f5d8372a31e49b120bd7029fdab03b2e2251b8cdd1e643f6fbfa14359f	2026-10-01 04:05:06.504873+00	20261001000000_bonus_pool_and_sale_item_bonus	\N	\N	2026-10-01 04:05:06.479623+00	1
645d6c4b-19ab-4191-be41-5b4c555931f5	5678e102c2799a99617688711f99c9d163e49aecee94583e95894db2cb58e25e	2026-10-01 06:21:20.435994+00	20261001120000_usd_cash_registers_and_payroll_month	\N	\N	2026-10-01 06:21:20.380503+00	1
c7781979-1c69-4495-b650-277d32a1a386	18db804735ec0b192fa17bc8702f03229aa3167dcedfd9f5e63cca7c39b2fdc8	2026-10-01 07:10:36.410261+00	20261001130000_store_profit_shares	\N	\N	2026-10-01 07:10:36.340726+00	1
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, "userId", "userName", "userRole", "storeName", action, details, "financialDetails", imei, "receiptNumber", "targetId", "ipAddress", "createdAt") FROM stdin;
1a1914cb-933b-4f71-94e9-92ba5e5243e3	user-admin	Далер	ADMIN	\N	SUPPLIER_BONUS	Зафиксирован бонус от Apple Dubai Wholesale LLC: $500	{"amountUsd": 500, "exchangeRate": 10.9}	\N	\N	ac49ac74-fc7f-490b-8330-efae6d2e90b6	\N	2026-10-01 03:50:31.635
b98bec03-c9c6-4a31-98db-3b932bf39962	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 03:59:29.478
19068d47-6d56-4eb8-84bc-17f9599fd79e	user-admin	\N	ADMIN	\N	RATE_CHANGE	Курс USD/TJS установлен: 1 USD = 10.50 TJS	{"exchangeRate": 10.5}	\N	\N	\N	\N	2026-10-01 03:59:29.575
2529b658-e9f5-4506-a19b-5fe5d6e96c03	user-admin	Далер	ADMIN	\N	USER_CREATE	Создан сотрудник: Audit Test Seller (SELLER)	\N	\N	\N	fedd2949-7160-41f3-9746-777719cee64e	\N	2026-10-01 03:59:30.063
a86bbc40-d2a5-4278-86ff-bbedb7a425f7	user-admin	Далер	ADMIN	\N	USER_DELETE	Удален сотрудник: Audit Test Seller (SELLER)	\N	\N	\N	\N	\N	2026-10-01 03:59:30.11
6951f72b-3640-4630-9d93-a9ec3bf96e4b	user-admin	Далер	ADMIN	\N	STORE_CREATE	Создан новый магазин: Филиал Аудит 1790827170144	\N	\N	\N	18632daf-8e2a-4d1e-a92d-09a05894da2e	\N	2026-10-01 03:59:30.166
4dff1e6f-d6ed-4745-ba10-cb9ea1551572	user-admin	Далер	ADMIN	\N	STORE_DELETE	Удален филиал: Филиал Аудит 1790827170144. Товары филиала перенесены на Главный склад	\N	\N	\N	\N	\N	2026-10-01 03:59:30.217
2bd9e4be-4515-415a-bda7-0d7426ceaa20	user-admin	Далер	ADMIN	\N	REPAIR_INTAKE	Принят на ремонт телефон Samsung Galaxy S24 Repair Audit (IMEI 357790827170362), квитанция #1. Неисправность: Замена дисплейного модуля	\N	357790827170362	\N	fb9050d6-cffb-451a-b56f-8d19dc6b1abd	\N	2026-10-01 03:59:30.41
7af8ebe9-aa0e-44da-be9c-2532b4962c2e	user-admin	Далер	ADMIN	\N	REPAIR_STATUS_CHANGE	Ремонт #1 (Galaxy S24 Repair Audit): статус "IN_PROGRESS".	\N	\N	\N	fb9050d6-cffb-451a-b56f-8d19dc6b1abd	\N	2026-10-01 03:59:30.477
0416762e-6580-4658-aaa1-1f7ea79ed075	user-admin	Далер	ADMIN	\N	EXPENSE	Зарегистрирован расход [UTILITIES]: 250 TJS ($23.81) (Магазин «Сиёма») — не оплачено	{"amountTjs": 250, "amountUsd": 23.81, "exchangeRate": 10.5}	\N	\N	20787901-4b8e-469c-9bc2-26f3d08bd8f1	\N	2026-10-01 03:59:30.541
9198fdda-4824-4915-84ce-8f58acf0cbd4	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 04:10:53.892
03300ce0-5578-434d-a531-46d61cc8858c	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 04:15:57.258
baeaf78d-a0b7-4931-8496-bdb24217c370	user-admin	Далер	ADMIN	\N	REPAIR_STATUS_CHANGE	Ремонт #1 (Galaxy S24 Repair Audit): статус "READY".	\N	\N	\N	fb9050d6-cffb-451a-b56f-8d19dc6b1abd	\N	2026-10-01 04:17:06.01
1d3b61f5-6d0b-4901-b497-bbb2320ff092	user-admin	Далер	ADMIN	\N	EXPENSE	Зарегистрирован расход [REPAIR_PARTS]: 250 TJS ($23.81) (Магазин «Сиёма»)	{"amountTjs": 250, "amountUsd": 23.81, "exchangeRate": 10.5}	\N	\N	502ac287-5d4f-44d9-b85e-85bd9343adb8	\N	2026-10-01 04:17:14.435
450ae4ed-9347-40e3-bfde-c02b89d28afb	user-admin	Далер	ADMIN	\N	REPAIR_STATUS_CHANGE	Ремонт #1 (Galaxy S24 Repair Audit): статус "ISSUED". Расход: 250 TJS списан с кассы магазина.	\N	\N	\N	fb9050d6-cffb-451a-b56f-8d19dc6b1abd	\N	2026-10-01 04:17:14.438
f1589668-d04f-48f3-ab07-3dc2f845b2a7	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 04:23:45.623
2bbab1e8-b75f-4cdf-b971-2438a4871544	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 04:24:23.526
d2b0ed25-f7ac-4283-aeae-a89f04c71daa	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 04:24:27.135
54daf619-97f8-4bb6-9381-3b8e3c1b7e33	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 04:25:00.337
b9c73468-df7d-4156-b446-212f75f168c4	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 05:22:14.174
b8fe9e58-5583-487c-94ab-dbe476d3e3e3	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 05:33:33.218
89a7ab02-a0cc-43f3-9e2b-8d2c002d8137	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 05:34:00.949
160e9a5b-5dd1-4538-bafb-f5132f80b42e	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 05:34:44.902
64fea408-8082-42fd-9100-6af89d066d90	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 05:36:52.203
b973ddcd-c30c-45f0-a6eb-4b7d6142656c	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 05:37:28.417
23fb70d2-ddcc-4d6b-bf5f-389423c7d64e	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 05:43:19.69
98b1c286-fb21-49f6-a60a-1180658be88f	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 05:51:43.459
a0bb82a2-4a1d-408b-bc9e-a3ac7d170e04	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 05:52:03.967
2f455065-4a12-486c-b8cc-d934b57a2de0	user-admin	\N	\N	\N	SALE	Чек #2: продажа 1 устройств на сумму 8900 TJS ($816.51)	{"amountTjs": 8900, "amountUsd": 816.51, "exchangeRate": 10.9, "bonusProfitUsd": 0, "recognizedProfitUsd": 96.51, "ownerProfitAllocations": [{"ownerId": "owner-admin", "amountUsd": 57.91}, {"ownerId": "owner-partner-tsum", "amountUsd": 38.6}]}	\N	2	44e64a40-3208-44cd-9072-57704d02a2ef	\N	2026-10-01 03:50:31.59
635e3b6f-2f4d-4d82-bb7d-c191433af06c	user-admin	Далер	ADMIN	\N	OWNER_INVESTMENT	Далер вложил $10000 в капитал (Магазин «Садбарг»)	{"amountUsd": 10000, "exchangeRate": 10.5}	\N	\N	\N	\N	2026-10-01 05:54:24.945
7b9a591b-3e95-410d-b474-9335a5f17246	user-admin	Далер	ADMIN	\N	OWNER_INVESTMENT	Рустам вложил $10000 в капитал (Магазин «Садбарг»)	{"amountUsd": 10000, "exchangeRate": 10.5}	\N	\N	\N	\N	2026-10-01 05:54:46.53
943312ff-dd3c-44c8-99ab-4c40605f6a3a	user-admin	Далер	ADMIN	\N	OWNER_INVESTMENT	Далер вложил $20000 в капитал (Магазин «Сиёма»)	{"amountUsd": 20000, "exchangeRate": 10.5}	\N	\N	\N	\N	2026-10-01 05:55:00.886
d0f6921a-d18c-43c9-9c71-a531072b6dd3	user-admin	Далер	ADMIN	\N	OWNER_INVESTMENT	Фаррух вложил $10000 в капитал (Магазин «Сиёма»)	{"amountUsd": 10000, "exchangeRate": 10.5}	\N	\N	\N	\N	2026-10-01 05:55:13.542
f0cfcdb5-3621-49cf-9176-2452344518aa	user-admin	Далер	ADMIN	\N	OWNER_INVESTMENT	Далер вложил $25000 в капитал (Магазин «ЦУМ»)	{"amountUsd": 25000, "exchangeRate": 10.5}	\N	\N	\N	\N	2026-10-01 05:55:43.751
69e19924-2f95-432e-819e-8792dc70fce3	user-admin	Далер	ADMIN	\N	OWNER_INVESTMENT	Сомон вложил $20000 в капитал (Магазин «ЦУМ»)	{"amountUsd": 20000, "exchangeRate": 10.5}	\N	\N	\N	\N	2026-10-01 05:55:56.885
df3e7be1-2a0c-403f-992e-921d823b72ce	user-admin	Далер	ADMIN	\N	OWNER_INVESTMENT	Далер вложил $50000 в капитал (Главный склад)	{"amountUsd": 50000, "exchangeRate": 10.5}	\N	\N	\N	\N	2026-10-01 05:56:21.804
8095c855-91a1-4b2f-a9e6-0ffe2c63612f	user-admin	Далер	ADMIN	\N	PROFIT_SHARE_CHANGE	Изменены доли партнеров: 60%, 40%, 40%, 40%	\N	\N	\N	\N	\N	2026-10-01 05:57:20.682
91cd6bb0-662e-409e-8805-768fa1f41258	user-admin	Далер	ADMIN	\N	REINVEST	Далер реинвестировал $696.69 доступной прибыли в капитал (Главный склад)	{"amountUsd": 696.69, "exchangeRate": 10.5}	\N	\N	\N	\N	2026-10-01 05:57:44.375
8d4113b4-7a7e-47c8-9154-3262aeb5f8a6	user-admin	Далер	ADMIN	\N	EXPENSE_PAID	Оплачен расход [UTILITIES]: 250 TJS ($23.81) из Центральной кассы	{"amountTjs": 250, "amountUsd": 23.81, "exchangeRate": 10.5}	\N	\N	20787901-4b8e-469c-9bc2-26f3d08bd8f1	\N	2026-10-01 06:01:22.36
fba26500-52e7-4fb8-88db-da9360c3aa7b	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 06:11:17.35
91018e3a-087c-4eb2-8f9a-2c19746438ad	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 06:11:37.731
0fc6a21c-be6b-4149-bf47-d46cdf49a509	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 06:12:24.531
adece8f1-c572-4db4-902a-1aeb8f24b599	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 06:12:46.764
db429772-42e9-4dc5-936b-be79cdbe549b	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 06:13:36.888
55417d8d-33ff-4b3c-b4cf-c49dd75dbecd	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 06:14:00.825
2ffbfb24-f44e-4403-96a8-46c903ac4954	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 06:14:42.208
b7a0afa5-001b-42d4-8e24-5626719546bd	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 06:15:31.303
43abd237-642a-4f5a-8211-33bad2fa01fd	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 06:16:32.628
3cca3a6f-020c-4df7-b566-389658ed8dc5	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 06:18:25.193
56696cc8-4109-4066-8a88-64ee97e9d567	\N	\N	\N	\N	CASH_REGISTER_USD_MIGRATION	Касса «Магазин «Садбарг»» переведена в доллары: 214000.00 TJS / 10.5000 = 20380.95 USD	{"exchangeRate": 10.5000, "cashBalanceTjs": 214000.00, "cashBalanceUsd": 20380.95, "previousAccountBalanceTjs": 214000.00}	\N	\N	store-sadbarg	\N	2026-10-01 06:21:20.389
0dd5780b-13c6-468c-bd7b-ced7e1e1d99f	\N	\N	\N	\N	CASH_REGISTER_USD_MIGRATION	Касса «Магазин «Сиёма»» переведена в доллары: 317700.00 TJS / 10.5000 = 30257.14 USD	{"exchangeRate": 10.5000, "cashBalanceTjs": 317700.00, "cashBalanceUsd": 30257.14, "previousAccountBalanceTjs": 317700.00}	\N	\N	store-siyoma	\N	2026-10-01 06:21:20.389
8043e02a-6543-4721-bb10-feec2c76d7c5	\N	\N	\N	\N	CASH_REGISTER_USD_MIGRATION	Касса «Магазин «ЦУМ»» переведена в доллары: 472500.00 TJS / 10.5000 = 45000.00 USD	{"exchangeRate": 10.5000, "cashBalanceTjs": 472500.00, "cashBalanceUsd": 45000.00, "previousAccountBalanceTjs": 472500.00}	\N	\N	store-tsum	\N	2026-10-01 06:21:20.389
00304f46-0c66-40fd-a3b2-7405d5b2591a	\N	\N	\N	\N	CASH_REGISTER_USD_MIGRATION	Касса «Главный склад» переведена в доллары: 524750.00 TJS / 10.5000 = 49976.19 USD	{"exchangeRate": 10.5000, "cashBalanceTjs": 524750.00, "cashBalanceUsd": 49976.19, "previousAccountBalanceTjs": 524750.00}	\N	\N	main-warehouse	\N	2026-10-01 06:21:20.389
fd2240db-4d16-4659-968c-bfe7bd08451d	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 06:21:49.608
d621c053-252e-4d57-8758-4da50b95b946	6d753871-ceb4-44bc-958a-b8fa4b75a6e5	Рустам (Партнёр Садбарг)	PARTNER	\N	LOGIN	Пользователь Рустам (Партнёр Садбарг) (PARTNER) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 06:21:56.973
c99d43c8-e095-4f43-b025-a802f2ef9f47	f4d04049-0f92-46f4-9109-c08dbd45cc10	Алишер (Продавец Садбарг)	SELLER	\N	LOGIN	Пользователь Алишер (Продавец Садбарг) (SELLER) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 06:22:06.503
af1bfa01-265a-446e-9935-744c1e4f26af	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 06:31:17.765
2a3321fd-3581-41ac-92e6-34596bcd65a7	6d753871-ceb4-44bc-958a-b8fa4b75a6e5	Рустам (Партнёр Садбарг)	PARTNER	\N	LOGIN	Пользователь Рустам (Партнёр Садбарг) (PARTNER) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 06:31:24.626
7668fbf5-e02b-4c8d-9f57-9ebe1e3f9e08	f4d04049-0f92-46f4-9109-c08dbd45cc10	Алишер (Продавец Садбарг)	SELLER	\N	LOGIN	Пользователь Алишер (Продавец Садбарг) (SELLER) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 06:31:34.381
6d203616-6bdf-40bd-91a8-f67b7bfdbe57	user-admin	\N	\N	\N	SALE	Чек #1: продажа 1 устройств на сумму 2950 TJS ($270.64)	{"amountTjs": 2950, "amountUsd": 270.64, "exchangeRate": 10.9, "bonusProfitUsd": 0, "recognizedProfitUsd": 50.64, "ownerProfitAllocations": [{"ownerId": "owner-admin", "amountUsd": 30.38}, {"ownerId": "owner-partner-siyoma", "amountUsd": 20.26}]}	\N	1	cf9a833f-bafb-4973-bf62-6dd5146cbd90	\N	2026-10-01 03:50:31.562
37c1f4fd-40dd-4c99-a27c-6a2f841f61ed	user-admin	\N	\N	\N	SALE	Чек #3: продажа 1 устройств на сумму 6400 TJS ($587.16)	{"amountTjs": 6400, "amountUsd": 587.16, "exchangeRate": 10.9, "bonusProfitUsd": 0, "recognizedProfitUsd": 97.16, "ownerProfitAllocations": [{"ownerId": "owner-admin", "amountUsd": 58.3}, {"ownerId": "owner-partner-sadbarg", "amountUsd": 38.86}]}	\N	3	80d98632-1ec6-43a2-be8c-9136ca9bc162	\N	2026-10-01 03:50:31.617
e46f1a51-c030-432b-8813-e33101fb507f	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 06:58:18.862
3fa83007-ce40-4ea3-b9fa-e27764b107be	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 07:09:26.664
37dd189e-61a0-4869-9591-43b8c0b0ac72	\N	\N	\N	\N	STORE_PROFIT_SHARE_MIGRATION	Доля партнёра «Рустам» в магазине «Магазин «Садбарг»» перенесена в доли по магазинам: 40.0000%	{"ownerId": "owner-partner-sadbarg", "storeId": "store-sadbarg", "sharePercent": 40.0000}	\N	\N	store-sadbarg	\N	2026-10-01 07:10:36.348
1002fbc9-1e27-4d50-8d0a-735e16f09029	\N	\N	\N	\N	STORE_PROFIT_SHARE_MIGRATION	Доля партнёра «Фаррух» в магазине «Магазин «Сиёма»» перенесена в доли по магазинам: 40.0000%	{"ownerId": "owner-partner-siyoma", "storeId": "store-siyoma", "sharePercent": 40.0000}	\N	\N	store-siyoma	\N	2026-10-01 07:10:36.348
8a99e624-3420-4db7-b674-698b71b949f5	\N	\N	\N	\N	STORE_PROFIT_SHARE_MIGRATION	Доля партнёра «Сомон» в магазине «Магазин «ЦУМ»» перенесена в доли по магазинам: 40.0000%	{"ownerId": "owner-partner-tsum", "storeId": "store-tsum", "sharePercent": 40.0000}	\N	\N	store-tsum	\N	2026-10-01 07:10:36.348
e9a79884-cd78-4ae9-bfac-135541463534	user-admin	Далер	ADMIN	\N	USER_UPDATE	Обновлены данные сотрудника: Рустам (Партнёр Садбарг) (PARTNER) (пароль изменен)	\N	\N	\N	6d753871-ceb4-44bc-958a-b8fa4b75a6e5	\N	2026-10-01 07:17:26.515
5333eeab-e41e-45b2-bdc1-52a33ef69a68	user-admin	Далер	ADMIN	\N	USER_STATUS_CHANGE	Сотрудник Рустам (Партнёр Садбарг) активирован	\N	\N	\N	6d753871-ceb4-44bc-958a-b8fa4b75a6e5	\N	2026-10-01 07:17:26.561
03bb1ed7-471d-48a5-b376-b43facb81774	user-admin	\N	ADMIN	\N	LOGOUT	Пользователь вышел из системы	\N	\N	\N	\N	\N	2026-10-01 07:17:30.355
6bde550e-b6ce-4c73-a6a6-03124fe12a4f	6d753871-ceb4-44bc-958a-b8fa4b75a6e5	Рустам (Партнёр Садбарг)	PARTNER	\N	LOGIN	Пользователь Рустам (Партнёр Садбарг) (PARTNER) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 07:17:35.862
95ab016a-3f2c-4605-88ef-9e34def6cede	6d753871-ceb4-44bc-958a-b8fa4b75a6e5	\N	PARTNER	\N	LOGOUT	Пользователь вышел из системы	\N	\N	\N	\N	\N	2026-10-01 07:17:50.335
05430c72-e022-4181-978e-f4312d792edf	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 07:18:00.947
d17f42c9-ef28-49ae-938b-8d82afece23c	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 07:21:12.015
ba374a71-2567-436c-924a-604f68f24a24	user-admin	Далер	ADMIN	\N	LOGIN	Пользователь Далер (ADMIN) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 07:21:56.679
98b0d9b6-c934-4f51-906a-a876e27af410	user-admin	\N	ADMIN	\N	LOGOUT	Пользователь вышел из системы	\N	\N	\N	\N	\N	2026-10-01 07:54:37.799
b0720465-c741-4900-8b2c-8980aba8eb3a	6d753871-ceb4-44bc-958a-b8fa4b75a6e5	Рустам (Партнёр Садбарг)	PARTNER	\N	LOGIN	Пользователь Рустам (Партнёр Садбарг) (PARTNER) вошел в систему	\N	\N	\N	\N	127.0.0.1	2026-10-01 07:54:41.081
\.


--
-- Data for Name: auth_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_sessions (id, "userId", "expiresAt", "revokedAt") FROM stdin;
a02e00da-7214-4f6a-9b6a-881bfbf5490c	user-admin	2026-09-24 22:39:59.874	\N
b640c960-7bae-4f25-9da3-75e33e631d61	user-admin	2026-09-25 15:33:12.246	\N
2bb56231-0e70-4cc5-aa0a-22c167e4726c	user-admin	2026-09-25 15:33:51.865	\N
09ca8c29-10ce-46d2-9810-5bec96d2ce10	user-admin	2026-09-25 15:34:30.78	\N
14086228-d874-40b0-8b00-6694b41027d0	user-admin	2026-10-01 17:37:28.402	\N
f186dd52-5d71-47c7-9a15-b7ff3ccad677	user-admin	2026-09-25 14:38:21.602	2026-09-25 03:40:06.754
beb5e0e6-1836-4668-b048-01e0c99bd89e	user-admin	2026-09-25 15:40:15.441	\N
256bc547-c61a-4294-9c89-91b9dd1d7c21	user-admin	2026-09-25 15:40:49.719	2026-09-25 03:54:31.192
71e36f10-6dc7-4031-b309-8c420b06acbe	user-admin	2026-09-25 15:56:24.313	\N
3297d456-4f60-4b0a-aef7-735c3cf2b9fd	user-admin	2026-09-26 00:24:16.454	\N
52e92079-0a15-4b05-8304-20d495ec8ff6	user-admin	2026-09-26 00:29:28.676	\N
07bb6cfa-bc64-456e-8173-337e77ae5494	user-admin	2026-09-26 00:31:19.895	\N
5bcb31c5-0033-4c43-b262-1024de432114	user-admin	2026-09-26 03:14:33.074	\N
0c42c47e-f695-4c33-b9a5-2146a4643d1c	user-admin	2026-09-26 03:14:40.964	\N
72431495-c10d-4b99-bf83-accb01ad213a	user-admin	2026-09-26 03:14:55.69	\N
63b43e75-3ba9-4e96-9c1c-814c0f9fe156	user-admin	2026-09-26 07:11:28.299	\N
e2615e76-afaf-4c1b-ad1e-345c4a1e4db2	user-admin	2026-09-26 07:11:49.734	\N
7aeaf185-121b-4782-9499-9bf7bb775f43	user-admin	2026-09-26 07:12:11.321	\N
82a930c8-69d9-4b41-a5e4-e284907da3c9	user-admin	2026-09-26 07:14:15.653	\N
c882009b-fcfd-45b8-8cd3-0324f95448b4	user-admin	2026-09-26 07:14:26.847	\N
3081f115-3a0c-4189-b00c-5cfbc7682338	user-admin	2026-09-26 07:28:06.407	\N
79a2f7b5-b3ab-4894-9a0c-fccc33dc4f25	user-admin	2026-09-26 07:28:14.923	\N
0092d6d9-b7e4-4bb7-b29e-d94032469e6c	user-admin	2026-09-26 07:28:40.72	\N
1b45d830-5df4-41ea-b39c-c42c65465c11	user-admin	2026-09-26 07:28:48.939	\N
b1066523-88a0-475b-a2bd-7b7fc1cda5a1	user-admin	2026-09-26 07:29:25.436	\N
ac50b6e3-c9ae-4881-8f31-b65ecfb0152a	user-admin	2026-09-26 07:29:51.513	\N
9759a0e1-e2ef-4933-9049-1b439a9b40f1	user-admin	2026-09-26 07:30:47.117	\N
f1257fff-a839-4187-9c1d-2b569aca9d70	user-admin	2026-09-26 07:38:06.899	\N
ee58dbd4-dbac-414f-82cb-60d7bede7478	user-admin	2026-09-26 07:38:25.951	\N
b9967c72-82eb-4f3c-8db7-57f500dbb3ca	user-admin	2026-09-26 07:38:50.677	\N
64181182-a3bb-4f04-a0d8-f0c6b2c075a8	user-admin	2026-09-26 07:39:39.481	\N
601ec300-c322-42c8-a4fc-58c1d72c9aed	user-admin	2026-09-26 07:42:28.783	\N
c1c4d2cc-e467-45d9-9aad-48d163e3b695	user-admin	2026-09-26 07:42:37.743	\N
d585dace-7500-4a0a-a4c9-7905d9372f72	user-admin	2026-09-26 07:42:46.949	\N
0f7cf937-d413-41a2-8605-9ec0ac91a954	user-admin	2026-09-26 07:44:18.364	\N
d0f931f4-29a3-47a6-8894-d1ff64a68b65	user-admin	2026-09-26 07:44:27.515	\N
23994328-722c-408c-96c4-d436955a2f4c	user-admin	2026-09-26 07:44:36.34	\N
b2ea83cc-5e60-448d-8cd7-de28b2259c83	user-admin	2026-09-26 19:04:17.301	\N
5c55d992-87ec-4dfb-aeef-6309b9fef7d3	user-admin	2026-09-27 07:05:09.24	\N
44762302-62da-4b92-805a-b52162055e45	user-admin	2026-09-28 04:08:12.651	\N
1798e786-2516-4a15-91af-ac84ff112a23	user-admin	2026-09-28 04:08:40.062	\N
534506f2-4945-49a9-b61f-a7129c095af3	user-admin	2026-09-28 04:24:24.551	\N
2cfb5ac7-4a6c-4ca9-9e32-5e4a241ce1a7	user-admin	2026-09-29 22:06:11.746	\N
fa8dfb5c-74e6-4c5b-84b1-b46bad0dcfe5	user-admin	2026-09-29 22:07:10.294	\N
42b236c0-7dd8-45e9-8055-8fbbffc53619	user-admin	2026-09-30 07:54:12.087	\N
34d29993-f59d-4dc6-a569-35c7abf53405	user-admin	2026-09-29 22:43:27.891	2026-09-29 20:14:31.465
a21fd4fe-af3e-49b4-8cba-d17c69025324	user-admin	2026-09-30 08:14:41.345	2026-09-29 20:36:48.276
f6ff3972-7e59-4b15-9dfe-ce53dc5a17a9	user-admin	2026-09-30 08:38:52.139	\N
9864f1d7-44a3-4751-8636-3a894fd7958c	user-admin	2026-09-30 08:44:34.032	\N
27ac1581-dcbf-4e06-bbe1-33c7d78939dd	user-admin	2026-09-30 08:44:39.354	\N
3a26747c-3a80-4e41-908e-158d5eb347aa	user-admin	2026-10-01 17:43:19.672	\N
269951c7-2e2e-4eff-a676-47f333003eb8	user-admin	2026-10-01 17:51:43.426	\N
68e8a0fb-8d5d-4dc0-ad58-a0724ed78c93	user-admin	2026-10-01 17:52:03.943	\N
6638f41a-ef39-4549-a875-5f222c63cd64	user-admin	2026-10-01 18:11:17.33	\N
beed66dd-263c-4a73-9383-1ef1c63c2813	user-admin	2026-09-30 08:44:47.261	\N
25e3197e-3876-492d-bc34-ea9631a10966	user-admin	2026-09-30 14:22:01.734	\N
9b0a573e-7284-408b-9db0-c36268ad305b	user-admin	2026-09-30 14:25:29.275	\N
df82afb3-9d7d-4268-9798-b626a702ea45	user-admin	2026-10-01 02:55:53.413	\N
0b201ea6-bf2f-41bf-8811-fed8b107dcab	user-admin	2026-10-01 15:59:29.451	\N
cc8db613-3f00-4d70-ba4e-f2e8b2f2f535	user-admin	2026-10-01 16:15:57.242	\N
a5b540e6-e44d-4b2a-b70a-15751ef9ff8f	user-admin	2026-10-01 16:23:45.607	\N
684133f7-8dec-41a2-b1f1-05576a1f1732	user-admin	2026-10-01 16:24:23.511	\N
3a7c845c-e4de-403c-a556-11878f767a7c	user-admin	2026-10-01 16:24:27.112	\N
4d693af6-73c3-4204-b29c-f30c6493e99a	user-admin	2026-10-01 16:25:00.324	\N
13c22ba9-eb9b-4dee-bce5-29dfce0df394	user-admin	2026-10-01 17:22:14.114	\N
4665041f-2f6a-4b33-8cba-4774b2ff048c	user-admin	2026-10-01 17:33:33.19	\N
997945db-2668-4f59-8abe-3a679ba217b3	user-admin	2026-10-01 17:34:00.929	\N
a6233a29-3951-4584-8cf3-4fe86e2d1364	user-admin	2026-10-01 17:34:44.881	\N
5f31fd48-d626-4a8b-937a-a745c5ccec65	user-admin	2026-10-01 17:36:52.185	\N
764b8ad6-612c-4164-81da-98c4a41f9141	user-admin	2026-10-01 18:11:37.717	\N
a6db0a2c-559e-426b-970a-4ff01a105b87	user-admin	2026-10-01 18:12:24.516	\N
45b577f6-9819-4440-be55-906b2778f18e	user-admin	2026-10-01 18:12:46.751	\N
f82b38c2-23aa-483a-9542-4428fda9d9c9	user-admin	2026-10-01 18:13:36.873	\N
e71e6acc-94db-427c-a5f7-b670391043c0	user-admin	2026-10-01 18:14:00.805	\N
2a271580-1c9c-4d83-a6bb-dd574ab17051	user-admin	2026-10-01 18:14:42.193	\N
e7fd3ab5-6791-4b84-8ef7-fa5b3a51fec5	user-admin	2026-10-01 18:15:31.284	\N
c7c1bcf5-370c-4f3e-b9b0-2f4238426fef	user-admin	2026-10-01 18:16:32.612	\N
5c083fff-bbe0-4fbc-991d-a5e35f4a0717	user-admin	2026-10-01 18:18:25.171	\N
7fa6cfc3-d89d-4b74-a42b-346a9a9c1647	user-admin	2026-10-01 18:21:49.59	\N
24910f9e-6700-47a1-948d-cfe7987f0584	f4d04049-0f92-46f4-9109-c08dbd45cc10	2026-10-01 18:22:06.491	\N
e7206bb1-f96e-4910-ac53-40a42abeb477	user-admin	2026-10-01 18:31:17.747	\N
a7f4af6a-6ff0-46e7-9fdf-80a2c8d85fd8	f4d04049-0f92-46f4-9109-c08dbd45cc10	2026-10-01 18:31:34.36	\N
3aa8a484-f1f3-4382-b1aa-73cf687dbd40	user-admin	2026-10-01 18:58:18.839	\N
eba58cd9-2b4c-4591-9c2c-ca7b3cb4a0e8	user-admin	2026-10-01 19:09:26.648	\N
dafcf87c-4a21-4266-b2da-5c937d3e1edf	6d753871-ceb4-44bc-958a-b8fa4b75a6e5	2026-10-01 18:21:56.956	2026-10-01 07:17:26.507
95c686ff-b16a-4710-8709-fb73f75f18de	6d753871-ceb4-44bc-958a-b8fa4b75a6e5	2026-10-01 18:31:24.61	2026-10-01 07:17:26.507
70402edb-cddc-44f2-aed1-920a214db3f0	user-admin	2026-10-01 16:10:53.859	2026-10-01 07:17:30.338
43d596e9-e013-4e43-b3b2-2030e798ed5d	6d753871-ceb4-44bc-958a-b8fa4b75a6e5	2026-10-01 19:17:35.843	2026-10-01 07:17:50.32
8f0e8c61-c70c-4caf-86bc-70c4d3186dda	user-admin	2026-10-01 19:21:12.003	\N
0796a4ce-22e4-4bfc-b655-c1ae72674742	user-admin	2026-10-01 19:21:56.669	\N
69052baf-1919-4719-9510-a1d5d3a27de9	user-admin	2026-10-01 19:18:00.916	2026-10-01 07:54:37.788
87d92585-a473-434b-895d-c242a8f2b0c3	6d753871-ceb4-44bc-958a-b8fa4b75a6e5	2026-10-01 19:54:41.05	\N
\.


--
-- Data for Name: bonus_distribution_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bonus_distribution_logs (id, "periodName", "totalAmountUsd", "totalAmountTjs", type, allocations, note, "performedByUserId", "performedByName", "createdAt") FROM stdin;
\.


--
-- Data for Name: bonus_pool_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bonus_pool_entries (id, "deviceId", "saleId", "saleItemId", imei, brand, model, "salePriceUsd", "salePriceTjs", "profitUsd", "profitTjs", status, "distributionId", "distributedAt", "distributedBy", "distributionNote", "annulledAt", "annulledBy", "annulledNote", "createdAt") FROM stdin;
\.


--
-- Data for Name: cash_handovers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cash_handovers (id, "storeId", "amountTjs", "exchangeRate", "amountUsd", "businessDate", "acceptedByUserId", "acceptedByName", "financialTransactionId", "createdAt") FROM stdin;
\.


--
-- Data for Name: customer_payment_allocations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_payment_allocations (id, "paymentId", "saleId", "allocatedAmountTjs") FROM stdin;
\.


--
-- Data for Name: customer_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customer_payments (id, "customerId", "amountTjs", "sourceAccount", "storeId", "createdByUserId", "createdAt", "exchangeRate") FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.customers (id, name, phone, "totalDebtTjs", "totalPaidTjs", "createdAt") FROM stdin;
\.


--
-- Data for Name: device_identifiers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.device_identifiers (identifier, device_id) FROM stdin;
35100163137611	8b296b6f-0d02-4c41-9e66-e4d1de43d05d
86100163137612	ec668089-8769-46ba-a770-601252eab3f9
35200163137613	edc4d430-d44b-4dbf-b0e1-a924937bf143
35100263137621	dc31d2f4-34e4-4763-a964-a801dde90920
35200263137622	982832be-aa97-48a2-8f7d-2da1c6333ad3
86100263137623	a868443c-a74d-4a5a-b8be-f26e151d97ac
35100363137631	ed5b1033-22dd-4cc7-ba0e-3596115c13d7
35100363137632	fb0ee6fc-3bd4-4fea-a4da-271db90ddf29
86100363137633	96f14612-60ce-4060-8a5c-7181b04cd18a
35100463137641	df819574-ffc2-4400-a02e-4977d25cd814
35200463137642	ca3f4737-9bce-4180-9c59-9f37f8d6b22f
\.


--
-- Data for Name: device_timeline_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.device_timeline_events (id, "deviceId", date, type, description, "userName", "storeName", "priceTjs", "priceUsd") FROM stdin;
7916275e-1a56-4104-8cc8-f31c5e05991e	8b296b6f-0d02-4c41-9e66-e4d1de43d05d	2026-10-01 03:50:31.401	PURCHASE	Приход по накладной INV-SIYOMA-631376	Далер	Магазин «Сиёма»	\N	750.00
b80d85d3-3650-4c62-838e-d86f02056a73	ec668089-8769-46ba-a770-601252eab3f9	2026-10-01 03:50:31.415	PURCHASE	Приход по накладной INV-SIYOMA-631376	Далер	Магазин «Сиёма»	\N	220.00
e6b9ad7f-6d7a-418b-a61c-b0dcf85db394	edc4d430-d44b-4dbf-b0e1-a924937bf143	2026-10-01 03:50:31.42	PURCHASE	Приход по накладной INV-SIYOMA-631376	Далер	Магазин «Сиёма»	\N	340.00
4348b180-f2bf-44e2-88df-d9a92c61495f	dc31d2f4-34e4-4763-a964-a801dde90920	2026-10-01 03:50:31.436	PURCHASE	Приход по накладной INV-TSUM-631376	Далер	Магазин «ЦУМ»	\N	980.00
a365ab66-048e-45f4-a0f9-144d3554141c	982832be-aa97-48a2-8f7d-2da1c6333ad3	2026-10-01 03:50:31.441	PURCHASE	Приход по накладной INV-TSUM-631376	Далер	Магазин «ЦУМ»	\N	720.00
9985c698-2278-44de-8735-54db5d0a8053	a868443c-a74d-4a5a-b8be-f26e151d97ac	2026-10-01 03:50:31.446	PURCHASE	Приход по накладной INV-TSUM-631376	Далер	Магазин «ЦУМ»	\N	680.00
0752b852-883a-4894-bd15-8bc3e6958619	ed5b1033-22dd-4cc7-ba0e-3596115c13d7	2026-10-01 03:50:31.458	PURCHASE	Приход по накладной INV-SADBARG-631376	Далер	Магазин «Садбарг»	\N	590.00
085e2faa-4346-4d07-bf0c-6d885f6cb9ba	fb0ee6fc-3bd4-4fea-a4da-271db90ddf29	2026-10-01 03:50:31.464	PURCHASE	Приход по накладной INV-SADBARG-631376	Далер	Магазин «Садбарг»	\N	490.00
d920e1bd-9a75-4610-8cf1-cf6533db1a35	96f14612-60ce-4060-8a5c-7181b04cd18a	2026-10-01 03:50:31.469	PURCHASE	Приход по накладной INV-SADBARG-631376	Далер	Магазин «Садбарг»	\N	130.00
e1c06eb6-55de-46b6-acdf-090e7c7ba09a	df819574-ffc2-4400-a02e-4977d25cd814	2026-10-01 03:50:31.482	PURCHASE	Приход по накладной INV-WH-631376	Далер	Главный склад	\N	1100.00
3b753310-01a9-421b-8a7f-00aa32a55d08	ca3f4737-9bce-4180-9c59-9f37f8d6b22f	2026-10-01 03:50:31.487	PURCHASE	Приход по накладной INV-WH-631376	Далер	Главный склад	\N	1050.00
6b463715-0802-443b-b71d-407a4ef35aab	ec668089-8769-46ba-a770-601252eab3f9	2026-10-01 03:50:31.534	SALE	Продано за 2950 TJS (чек #1)	user-admin	\N	2950.00	270.64
098c1bf0-6d89-40cc-8eb0-b78fbd1ac4e4	982832be-aa97-48a2-8f7d-2da1c6333ad3	2026-10-01 03:50:31.579	SALE	Продано за 8900 TJS (чек #2)	user-admin	\N	8900.00	816.51
79c51167-ec16-41fc-9edc-118b35765859	fb0ee6fc-3bd4-4fea-a4da-271db90ddf29	2026-10-01 03:50:31.605	SALE	Продано за 6400 TJS (чек #3)	user-admin	\N	6400.00	587.16
\.


--
-- Data for Name: devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.devices (id, imei, imei2, brand, model, storage, color, status, "storeId", "purchasePriceUsd", "costBasisUsd", "retailPriceTjs", "receivedDate", "isBonus", "bonusCampaign", "supplierId", "supplierName", "invoiceNumber", "purchaseInvoiceId", "createdAt", "updatedAt", ram) FROM stdin;
8b296b6f-0d02-4c41-9e66-e4d1de43d05d	35100163137611	\N	Apple	iPhone 15	128GB	Black	STORE_STOCK	store-siyoma	750.00	750.00	\N	\N	f	\N	sup-dubai-wholesale	Apple Dubai Wholesale LLC	INV-SIYOMA-631376	9059ed95-f9aa-4200-b0b4-7664ce350923	2026-10-01 03:50:31.401	2026-10-01 03:50:31.401	6GB
edc4d430-d44b-4dbf-b0e1-a924937bf143	35200163137613	\N	Samsung	Galaxy A55	256GB	Awesome Navy	STORE_STOCK	store-siyoma	340.00	340.00	\N	\N	f	\N	sup-dubai-wholesale	Apple Dubai Wholesale LLC	INV-SIYOMA-631376	9059ed95-f9aa-4200-b0b4-7664ce350923	2026-10-01 03:50:31.42	2026-10-01 03:50:31.42	8GB
dc31d2f4-34e4-4763-a964-a801dde90920	35100263137621	\N	Apple	iPhone 15 Pro	256GB	Natural Titanium	STORE_STOCK	store-tsum	980.00	980.00	\N	\N	f	\N	sup-dubai-wholesale	Apple Dubai Wholesale LLC	INV-TSUM-631376	682becf3-486e-445e-97ff-e28d49fec071	2026-10-01 03:50:31.436	2026-10-01 03:50:31.436	8GB
a868443c-a74d-4a5a-b8be-f26e151d97ac	86100263137623	\N	Xiaomi	Xiaomi 14	512GB	White	STORE_STOCK	store-tsum	680.00	680.00	\N	\N	f	\N	sup-dubai-wholesale	Apple Dubai Wholesale LLC	INV-TSUM-631376	682becf3-486e-445e-97ff-e28d49fec071	2026-10-01 03:50:31.446	2026-10-01 03:50:31.446	12GB
ed5b1033-22dd-4cc7-ba0e-3596115c13d7	35100363137631	\N	Apple	iPhone 14	128GB	Midnight	STORE_STOCK	store-sadbarg	590.00	590.00	\N	\N	f	\N	sup-dubai-wholesale	Apple Dubai Wholesale LLC	INV-SADBARG-631376	e880a8ef-42d3-4415-a51c-1c7439a99792	2026-10-01 03:50:31.458	2026-10-01 03:50:31.458	6GB
96f14612-60ce-4060-8a5c-7181b04cd18a	86100363137633	\N	Xiaomi	Redmi 13C	128GB	Glacier White	STORE_STOCK	store-sadbarg	130.00	130.00	\N	\N	f	\N	sup-dubai-wholesale	Apple Dubai Wholesale LLC	INV-SADBARG-631376	e880a8ef-42d3-4415-a51c-1c7439a99792	2026-10-01 03:50:31.469	2026-10-01 03:50:31.469	6GB
df819574-ffc2-4400-a02e-4977d25cd814	35100463137641	\N	Apple	iPhone 15 Pro Max	256GB	Blue Titanium	MAIN_WAREHOUSE	main-warehouse	1100.00	1100.00	\N	\N	f	\N	sup-dubai-wholesale	Apple Dubai Wholesale LLC	INV-WH-631376	06806ace-8464-409d-a7e3-54204e7b5a82	2026-10-01 03:50:31.482	2026-10-01 03:50:31.482	8GB
ca3f4737-9bce-4180-9c59-9f37f8d6b22f	35200463137642	\N	Samsung	Galaxy S24 Ultra	512GB	Titanium Gray	MAIN_WAREHOUSE	main-warehouse	1050.00	1050.00	\N	\N	f	\N	sup-dubai-wholesale	Apple Dubai Wholesale LLC	INV-WH-631376	06806ace-8464-409d-a7e3-54204e7b5a82	2026-10-01 03:50:31.487	2026-10-01 03:50:31.487	12GB
ec668089-8769-46ba-a770-601252eab3f9	86100163137612	\N	Xiaomi	Redmi Note 13 Pro	256GB	Midnight Black	SOLD	store-siyoma	220.00	220.00	\N	\N	f	\N	sup-dubai-wholesale	Apple Dubai Wholesale LLC	INV-SIYOMA-631376	9059ed95-f9aa-4200-b0b4-7664ce350923	2026-10-01 03:50:31.415	2026-10-01 03:50:31.532	8GB
982832be-aa97-48a2-8f7d-2da1c6333ad3	35200263137622	\N	Samsung	Galaxy S24	256GB	Onyx Black	SOLD	store-tsum	720.00	720.00	\N	\N	f	\N	sup-dubai-wholesale	Apple Dubai Wholesale LLC	INV-TSUM-631376	682becf3-486e-445e-97ff-e28d49fec071	2026-10-01 03:50:31.441	2026-10-01 03:50:31.578	8GB
fb0ee6fc-3bd4-4fea-a4da-271db90ddf29	35100363137632	\N	Apple	iPhone 13	128GB	Starlight	SOLD	store-sadbarg	490.00	490.00	\N	\N	f	\N	sup-dubai-wholesale	Apple Dubai Wholesale LLC	INV-SADBARG-631376	e880a8ef-42d3-4415-a51c-1c7439a99792	2026-10-01 03:50:31.464	2026-10-01 03:50:31.603	4GB
\.


--
-- Data for Name: document_sequences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_sequences (key, "nextValue") FROM stdin;
CR-2026	3
OD-2026	8
CE-2026	3
\.


--
-- Data for Name: exchange_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.exchange_events (id, "saleId", date, "returnedDeviceId", "returnedImei", "returnedModel", "exchangeInValueTjs", "exchangeInValueUsd", "replacementDeviceId", "replacementImei", "replacementModel", "newPriceTjs", "newPriceUsd", "differenceTjs", "paymentMethod", "cashAmountTjs", "cardAmountTjs", "processedByUserId", "exchangeRate") FROM stdin;
\.


--
-- Data for Name: exchange_rates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.exchange_rates (id, date, rate, "createdByUserId", "createdAt", "updatedByUserId", "updatedAt") FROM stdin;
e756d81f-432f-474c-bdcc-1f642b16b6c4	2026-10-01	10.5000	user-admin	2026-10-01 03:50:31.315	user-admin	2026-10-01 03:59:29.567
\.


--
-- Data for Name: expenses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.expenses (id, category, "amountTjs", "amountUsd", "exchangeRate", "targetType", "storeId", "sourceAccount", comment, description, "createdByUserId", "paidFromCashRegister", "employeeId", "isEmployeeAdvance", "createdAt", "cancelledAt", "cancelledByUserId", "ownerProfitAllocations", status, "paidAt", "payrollMonth") FROM stdin;
502ac287-5d4f-44d9-b85e-85bd9343adb8	REPAIR_PARTS	250.00	23.81	10.5000	STORE	store-siyoma	Касса Магазин «Сиёма»	Выдача ремонта #1: Samsung Galaxy S24 Repair Audit	\N	user-admin	t	\N	f	2026-10-01 04:17:14.396	\N	\N	[{"ownerId": "owner-admin", "amountUsd": 23.81}]	PAID	2026-10-01 04:17:14.394	\N
20787901-4b8e-469c-9bc2-26f3d08bd8f1	UTILITIES	250.00	23.81	10.5000	STORE	store-siyoma	Центральная касса	\N	Оплата коммунальных услуг за текущий месяц	user-admin	t	\N	f	2026-10-01 03:59:30.529	\N	\N	[{"ownerId": "owner-admin", "amountUsd": 23.81}]	PAID	2026-10-01 06:01:22.345	\N
\.


--
-- Data for Name: financial_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.financial_accounts (id, name, type, "storeId", active, "openingBalanceTjs", "openingBalanceUsd", "balanceTjs", "balanceUsd", "createdAt", "updatedAt") FROM stdin;
7be30a85-8970-4c66-9a39-ec83a7f12194	Главный счёт	MAIN	\N	f	0.00	0.00	0.00	0.00	2026-09-17 15:27:48.926	2026-10-01 03:48:48.119
fin-acc-store-sadbarg	Касса Магазин «Садбарг»	CASH	store-sadbarg	t	0.00	0.00	0.00	20380.95	2026-10-01 03:50:31.366	2026-10-01 05:54:46.515
b42499d9-9594-4a3d-849c-5837b355a326	Касса Магазин «Сиёма»	CASH	store-siyoma	t	0.00	0.00	0.00	30257.14	2026-09-17 15:27:48.916	2026-10-01 05:55:13.529
fin-acc-store-tsum	Касса Магазин «ЦУМ»	CASH	store-tsum	t	0.00	0.00	0.00	45000.00	2026-10-01 03:50:31.355	2026-10-01 05:55:56.877
03df27a8-e907-4b73-9ec9-be343b431f53	Касса Главный склад	CASH	main-warehouse	t	0.00	0.00	0.00	49976.19	2026-09-17 15:27:48.904	2026-10-01 06:01:22.3
\.


--
-- Data for Name: financial_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.financial_categories (id, name, direction, "parentId", "isSystem", active, "createdAt") FROM stdin;
4bd6f90f-272d-4341-bbd4-5e77c5126c42	Продажа	IN	\N	t	t	2026-10-01 03:50:31.544
43de896d-23d3-4f79-bce2-354f11f0d514	REPAIR_PARTS	OUT	\N	t	t	2026-10-01 04:17:14.415
0950c4fb-c5f1-4cad-8a7f-9671dcffb827	Взнос владельца	IN	\N	t	t	2026-10-01 05:54:24.932
60109cf1-81b1-41cb-8d3d-312a12b5ec21	UTILITIES	OUT	\N	t	t	2026-10-01 06:01:22.312
\.


--
-- Data for Name: financial_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.financial_transactions (id, "transactionNumber", type, direction, status, "transactionDate", "accountId", "destinationAccountId", amount, currency, "exchangeRate", "amountTjs", "amountUsd", "categoryId", "counterpartyType", "counterpartyId", "counterpartyName", "shopId", "sourceType", "sourceId", "reversedTransactionId", description, comment, "createdByUserId", "createdAt", "updatedAt", "cancelledAt", "cancelledByUserId", "balanceCurrency", "idempotencyKey") FROM stdin;
88ec781e-3eea-4890-b26e-ff30f0e9a034	CR-2026-000001	INCOME	IN	POSTED	2026-10-01 03:50:31.547	b42499d9-9594-4a3d-849c-5837b355a326	\N	2950.00	TJS	10.9000	2950.00	270.64	4bd6f90f-272d-4341-bbd4-5e77c5126c42	\N	\N	\N	store-siyoma	SALE	cf9a833f-bafb-4973-bf62-6dd5146cbd90	\N	Чек #1: продажа наличными	\N	user-admin	2026-10-01 03:50:31.549	2026-10-01 03:50:31.549	\N	\N	TJS	\N
e985c0c1-8e7e-4830-a9be-72db479c7b93	CR-2026-000002	INCOME	IN	POSTED	2026-10-01 03:50:31.61	fin-acc-store-sadbarg	\N	4000.00	TJS	10.9000	4000.00	366.97	4bd6f90f-272d-4341-bbd4-5e77c5126c42	\N	\N	\N	store-sadbarg	SALE	80d98632-1ec6-43a2-be8c-9136ca9bc162	\N	Чек #3: продажа наличными	\N	user-admin	2026-10-01 03:50:31.611	2026-10-01 03:50:31.611	\N	\N	TJS	\N
b0f8fffa-7d4e-4a57-b231-13dbe0c8f184	CE-2026-000001	EXPENSE	OUT	POSTED	2026-10-01 04:17:14.421	b42499d9-9594-4a3d-849c-5837b355a326	\N	250.00	TJS	10.5000	250.00	23.81	43de896d-23d3-4f79-bce2-354f11f0d514	\N	\N	\N	store-siyoma	EXPENSE	502ac287-5d4f-44d9-b85e-85bd9343adb8	\N	Выдача ремонта #1: Samsung Galaxy S24 Repair Audit	Выдача ремонта #1: Samsung Galaxy S24 Repair Audit	user-admin	2026-10-01 04:17:14.422	2026-10-01 04:17:14.422	\N	\N	TJS	\N
c0ffe36d-28cc-406f-8da3-8bc5b13004c6	OD-2026-000001	OWNER_DEPOSIT	IN	POSTED	2026-10-01 05:54:24.936	fin-acc-store-sadbarg	\N	10000.00	USD	10.5000	105000.00	10000.00	0950c4fb-c5f1-4cad-8a7f-9671dcffb827	OWNER	owner-admin	Далер	store-sadbarg	OWNER_TRANSACTION	1257245d-b623-43c1-b2da-b217e2cf79d7	\N	Далер вложил $10000 в капитал (Магазин «Садбарг»)	\N	user-admin	2026-10-01 05:54:24.937	2026-10-01 05:54:24.937	\N	\N	TJS	\N
e1161772-ca37-4c03-842d-6f633164619b	OD-2026-000002	OWNER_DEPOSIT	IN	POSTED	2026-10-01 05:54:46.521	fin-acc-store-sadbarg	\N	10000.00	USD	10.5000	105000.00	10000.00	0950c4fb-c5f1-4cad-8a7f-9671dcffb827	OWNER	owner-partner-sadbarg	Рустам	store-sadbarg	OWNER_TRANSACTION	11a3f487-9b89-4606-a431-546d7d027c1f	\N	Рустам вложил $10000 в капитал (Магазин «Садбарг»)	\N	user-admin	2026-10-01 05:54:46.523	2026-10-01 05:54:46.523	\N	\N	TJS	\N
e1698744-8a09-41a9-9cef-47475da86ece	OD-2026-000003	OWNER_DEPOSIT	IN	POSTED	2026-10-01 05:55:00.879	b42499d9-9594-4a3d-849c-5837b355a326	\N	20000.00	USD	10.5000	210000.00	20000.00	0950c4fb-c5f1-4cad-8a7f-9671dcffb827	OWNER	owner-admin	Далер	store-siyoma	OWNER_TRANSACTION	7e76805f-bd10-4ffd-bed4-03732d3908c0	\N	Далер вложил $20000 в капитал (Магазин «Сиёма»)	\N	user-admin	2026-10-01 05:55:00.88	2026-10-01 05:55:00.88	\N	\N	TJS	\N
8b3fdece-af09-4de3-b452-17b597f9beff	OD-2026-000004	OWNER_DEPOSIT	IN	POSTED	2026-10-01 05:55:13.534	b42499d9-9594-4a3d-849c-5837b355a326	\N	10000.00	USD	10.5000	105000.00	10000.00	0950c4fb-c5f1-4cad-8a7f-9671dcffb827	OWNER	owner-partner-siyoma	Фаррух	store-siyoma	OWNER_TRANSACTION	90e843c8-3bfc-4033-bea3-ba0924f196a9	\N	Фаррух вложил $10000 в капитал (Магазин «Сиёма»)	\N	user-admin	2026-10-01 05:55:13.536	2026-10-01 05:55:13.536	\N	\N	TJS	\N
0056ccc5-730a-4fd3-8c3a-af95b4088cf6	OD-2026-000005	OWNER_DEPOSIT	IN	POSTED	2026-10-01 05:55:43.734	fin-acc-store-tsum	\N	25000.00	USD	10.5000	262500.00	25000.00	0950c4fb-c5f1-4cad-8a7f-9671dcffb827	OWNER	owner-admin	Далер	store-tsum	OWNER_TRANSACTION	6d65557a-dae4-41a0-9a5d-ed3c959ead24	\N	Далер вложил $25000 в капитал (Магазин «ЦУМ»)	\N	user-admin	2026-10-01 05:55:43.736	2026-10-01 05:55:43.736	\N	\N	TJS	\N
fe446da5-4d2c-4f5a-9ee7-00abade18d7d	OD-2026-000006	OWNER_DEPOSIT	IN	POSTED	2026-10-01 05:55:56.88	fin-acc-store-tsum	\N	20000.00	USD	10.5000	210000.00	20000.00	0950c4fb-c5f1-4cad-8a7f-9671dcffb827	OWNER	owner-partner-tsum	Сомон	store-tsum	OWNER_TRANSACTION	84404c8c-aab2-4da4-ba41-70ccc30c42df	\N	Сомон вложил $20000 в капитал (Магазин «ЦУМ»)	\N	user-admin	2026-10-01 05:55:56.881	2026-10-01 05:55:56.881	\N	\N	TJS	\N
9c46aef2-c80d-48e9-9913-57c4da393d54	OD-2026-000007	OWNER_DEPOSIT	IN	POSTED	2026-10-01 05:56:21.792	03df27a8-e907-4b73-9ec9-be343b431f53	\N	50000.00	USD	10.5000	525000.00	50000.00	0950c4fb-c5f1-4cad-8a7f-9671dcffb827	OWNER	owner-admin	Далер	main-warehouse	OWNER_TRANSACTION	f3b533eb-c32c-48e1-9cb4-b26e1126f5ef	\N	Далер вложил $50000 в капитал (Главный склад)	\N	user-admin	2026-10-01 05:56:21.795	2026-10-01 05:56:21.795	\N	\N	TJS	\N
d53bd658-ac68-4a02-a9c3-e5c559dba0ea	CE-2026-000002	EXPENSE	OUT	POSTED	2026-10-01 06:01:22.319	03df27a8-e907-4b73-9ec9-be343b431f53	\N	250.00	TJS	10.5000	250.00	23.81	60109cf1-81b1-41cb-8d3d-312a12b5ec21	\N	\N	\N	store-siyoma	EXPENSE	20787901-4b8e-469c-9bc2-26f3d08bd8f1	\N	Оплата коммунальных услуг за текущий месяц	\N	user-admin	2026-10-01 06:01:22.321	2026-10-01 06:01:22.321	\N	\N	TJS	\N
\.


--
-- Data for Name: invoice_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_groups (id, "invoiceId", brand, model, storage, color, quantity, "purchasePriceUsd", ram) FROM stdin;
0766e948-d1cc-4bd6-ac31-7c30c24dfe5d	9059ed95-f9aa-4200-b0b4-7664ce350923	Apple	iPhone 15	128GB	Black	1	750.00	6GB
56e71162-8da8-4d2c-ae8b-5642e36acce4	9059ed95-f9aa-4200-b0b4-7664ce350923	Xiaomi	Redmi Note 13 Pro	256GB	Midnight Black	1	220.00	8GB
68a1a0fe-6d26-4742-9666-6640d8e7642b	9059ed95-f9aa-4200-b0b4-7664ce350923	Samsung	Galaxy A55	256GB	Awesome Navy	1	340.00	8GB
e76f8062-d954-4ed5-a4b4-6d7cd2953685	682becf3-486e-445e-97ff-e28d49fec071	Apple	iPhone 15 Pro	256GB	Natural Titanium	1	980.00	8GB
910f9f43-c67f-40b2-a2a1-22c6c94f0059	682becf3-486e-445e-97ff-e28d49fec071	Samsung	Galaxy S24	256GB	Onyx Black	1	720.00	8GB
46fd18a7-4161-4098-a9de-a223d5d26c0d	682becf3-486e-445e-97ff-e28d49fec071	Xiaomi	Xiaomi 14	512GB	White	1	680.00	12GB
8aa83a62-fcf5-4647-9f52-f3bb385f1a77	e880a8ef-42d3-4415-a51c-1c7439a99792	Apple	iPhone 14	128GB	Midnight	1	590.00	6GB
c6a33184-5b33-4ef1-834c-d53ca54e86ca	e880a8ef-42d3-4415-a51c-1c7439a99792	Apple	iPhone 13	128GB	Starlight	1	490.00	4GB
c61e0f54-b6ac-4e45-a281-0166fe797779	e880a8ef-42d3-4415-a51c-1c7439a99792	Xiaomi	Redmi 13C	128GB	Glacier White	1	130.00	6GB
962329f9-8038-4fbb-ad85-25152f057e54	06806ace-8464-409d-a7e3-54204e7b5a82	Apple	iPhone 15 Pro Max	256GB	Blue Titanium	1	1100.00	8GB
6cd8c36f-4961-4092-9ded-925b25499cb7	06806ace-8464-409d-a7e3-54204e7b5a82	Samsung	Galaxy S24 Ultra	512GB	Titanium Gray	1	1050.00	12GB
\.


--
-- Data for Name: ledger_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ledger_entries (id, type, description, "amountTjs", "amountUsd", "exchangeRate", "storeId", "storeName", "userName", "referenceId", "createdAt") FROM stdin;
baa40f3c-8fb3-4cf6-9e34-616148ee5b3d	CASH_SALE	Чек #1: продажа 1 устройств	2950.00	270.64	10.9000	store-siyoma	Магазин «Сиёма»	\N	cf9a833f-bafb-4973-bf62-6dd5146cbd90	2026-10-01 03:50:31.559
5c2dda57-c890-4e1e-b7da-cba01dee7885	CARD_SALE	Чек #2: продажа 1 устройств	8900.00	816.51	10.9000	store-tsum	Магазин «ЦУМ»	\N	44e64a40-3208-44cd-9072-57704d02a2ef	2026-10-01 03:50:31.588
ee28e642-5f14-44ac-8fed-05660271693b	SALE	Чек #3: продажа 1 устройств	6400.00	587.16	10.9000	store-sadbarg	Магазин «Садбарг»	\N	80d98632-1ec6-43a2-be8c-9136ca9bc162	2026-10-01 03:50:31.615
9818ee59-c7d6-4204-a348-b5bc7f705f64	SUPPLIER_BONUS	Денежный бонус от Apple Dubai Wholesale LLC: +$500	\N	500.00	10.9000	\N	\N	Далер	ac49ac74-fc7f-490b-8330-efae6d2e90b6	2026-10-01 03:50:31.633
759f711c-936d-4c80-a452-1e18c918935c	EXPENSE	Оплата коммунальных услуг за текущий месяц	-250.00	-23.81	10.5000	store-siyoma	Магазин «Сиёма»	Далер	20787901-4b8e-469c-9bc2-26f3d08bd8f1	2026-10-01 03:59:30.537
389fa4f5-68cd-4cda-b1fb-5ca79ec2db9b	EXPENSE	Выдача ремонта #1: Samsung Galaxy S24 Repair Audit	-250.00	-23.81	10.5000	store-siyoma	Магазин «Сиёма»	Далер	502ac287-5d4f-44d9-b85e-85bd9343adb8	2026-10-01 04:17:14.431
902ec517-ab60-4d3e-8f96-3cf288f407fc	OWNER_INVESTMENT	Далер вложил $10000 в капитал (Магазин «Садбарг»)	\N	10000.00	10.5000	store-sadbarg	Магазин «Садбарг»	Далер	\N	2026-10-01 05:54:24.942
e092dbe0-521c-4cbd-8dfa-37ecc7156410	OWNER_INVESTMENT	Рустам вложил $10000 в капитал (Магазин «Садбарг»)	\N	10000.00	10.5000	store-sadbarg	Магазин «Садбарг»	Далер	\N	2026-10-01 05:54:46.527
d8b201dc-c8cf-4fde-aafe-5f85187a723f	OWNER_INVESTMENT	Далер вложил $20000 в капитал (Магазин «Сиёма»)	\N	20000.00	10.5000	store-siyoma	Магазин «Сиёма»	Далер	\N	2026-10-01 05:55:00.884
45064396-eb86-40dc-ad8e-9a786f92fd7b	OWNER_INVESTMENT	Фаррух вложил $10000 в капитал (Магазин «Сиёма»)	\N	10000.00	10.5000	store-siyoma	Магазин «Сиёма»	Далер	\N	2026-10-01 05:55:13.539
880048a7-3c5a-455f-b56f-9ce0631caba6	OWNER_INVESTMENT	Далер вложил $25000 в капитал (Магазин «ЦУМ»)	\N	25000.00	10.5000	store-tsum	Магазин «ЦУМ»	Далер	\N	2026-10-01 05:55:43.747
49eeff87-07d8-4f45-88dc-6fae6f2bd6ab	OWNER_INVESTMENT	Сомон вложил $20000 в капитал (Магазин «ЦУМ»)	\N	20000.00	10.5000	store-tsum	Магазин «ЦУМ»	Далер	\N	2026-10-01 05:55:56.883
22b0070b-c031-4044-bca4-d3238e975a8c	OWNER_INVESTMENT	Далер вложил $50000 в капитал (Главный склад)	\N	50000.00	10.5000	main-warehouse	Главный склад	Далер	\N	2026-10-01 05:56:21.801
395655f8-a3b0-4fc2-9dec-3546284a37e5	OWNER_REINVESTMENT	Далер реинвестировал $696.69 доступной прибыли в капитал (Главный склад)	\N	696.69	10.5000	main-warehouse	Главный склад	Далер	\N	2026-10-01 05:57:44.368
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, title, message, "targetType", "targetId", "targetRoute", "targetRole", "targetUserId", read, resolved, "readAt", "resolvedAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: operation_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.operation_requests (key, fingerprint, result, created_at) FROM stdin;
user-admin:7c1fe3731725bdc8620bfca42c93d363	5af6d50257f28bee5ad0a875dc430e179774d343f0a537c0a0906325b54e4408	{"id": "fb9050d6-cffb-451a-b56f-8d19dc6b1abd", "imei": "357790827170362", "brand": "Samsung", "color": "Phantom Black", "imei2": null, "model": "Galaxy S24 Repair Audit", "status": "READY", "userId": "user-admin", "comment": null, "storage": "256GB", "storeId": "store-siyoma", "deviceId": null, "saleDate": null, "createdAt": "2026-10-01T03:59:30.396Z", "updatedAt": "2026-10-01T04:17:06.001Z", "customerName": null, "exchangeRate": null, "finalCostTjs": 0, "finalCostUsd": 0, "ticketNumber": 1, "customerPhone": null, "prepaymentTjs": null, "visualCondition": null, "equipmentPackage": null, "estimatedCostTjs": null, "estimatedCostUsd": null, "saleReceiptNumber": null, "problemDescription": "Замена дисплейного модуля"}	2026-10-01 04:17:05.980726+00
user-admin:70ac1e8d5315a67a08eb44baf9795f97	08b040895b57f5176479668a4dfe1f0a3fe17ea4060c18ad365362e489ade9d5	{"id": "fb9050d6-cffb-451a-b56f-8d19dc6b1abd", "imei": "357790827170362", "brand": "Samsung", "color": "Phantom Black", "imei2": null, "model": "Galaxy S24 Repair Audit", "status": "ISSUED", "userId": "user-admin", "comment": null, "storage": "256GB", "storeId": "store-siyoma", "deviceId": null, "saleDate": null, "createdAt": "2026-10-01T03:59:30.396Z", "updatedAt": "2026-10-01T04:17:14.371Z", "customerName": null, "exchangeRate": 10.5, "finalCostTjs": 250, "finalCostUsd": 23.81, "ticketNumber": 1, "customerPhone": null, "prepaymentTjs": null, "visualCondition": null, "equipmentPackage": null, "estimatedCostTjs": null, "estimatedCostUsd": null, "saleReceiptNumber": null, "problemDescription": "Замена дисплейного модуля"}	2026-10-01 04:17:14.343599+00
user-admin:d0d309c668e890f00aef2989425e7f7c	f30be34f7042a29ede3b7ad5bcce2576110947fa25cc2ad2a997918c3a01abd8	{"id": "owner-admin", "name": "Далер", "userId": "user-admin", "storeId": null, "createdAt": "2026-09-17T15:26:45.325Z", "capitalBalanceUsd": 10000, "availableProfitUsd": 696.69, "profitSharePercent": 60, "totalPaidProfitUsd": 0, "totalReinvestedUsd": 0, "totalAccruedProfitUsd": 696.69}	2026-10-01 05:54:24.877451+00
user-admin:025eb63b3df1e5c90a6bcee7330c0515	77516bf811aeca2c83d41f6983e6ba05f135c24243a9bb784c20eab7007cdb6b	{"id": "owner-partner-sadbarg", "name": "Рустам", "userId": "6d753871-ceb4-44bc-958a-b8fa4b75a6e5", "storeId": "store-sadbarg", "createdAt": "2026-10-01T05:17:21.683Z", "capitalBalanceUsd": 10000, "availableProfitUsd": 0, "profitSharePercent": 40, "totalPaidProfitUsd": 0, "totalReinvestedUsd": 0, "totalAccruedProfitUsd": 0}	2026-10-01 05:54:46.490435+00
user-admin:25ccbfb11ae75c453ba709aed93cc3a8	578e13bb96339360b9d22952c564ef992cd566df567e44031649eedaa5f2205f	{"id": "owner-admin", "name": "Далер", "userId": "user-admin", "storeId": null, "createdAt": "2026-09-17T15:26:45.325Z", "capitalBalanceUsd": 30000, "availableProfitUsd": 696.69, "profitSharePercent": 60, "totalPaidProfitUsd": 0, "totalReinvestedUsd": 0, "totalAccruedProfitUsd": 696.69}	2026-10-01 05:55:00.852079+00
user-admin:a71fb411c5613a5d2bd21d077c62e7b3	0fa52132a430c8236355274df07de6ea9c0b6867e0abb0bf918f157d5edc814d	{"id": "owner-partner-siyoma", "name": "Фаррух", "userId": "fcd65abe-134e-48c1-81d3-41704bc954b0", "storeId": "store-siyoma", "createdAt": "2026-10-01T05:17:21.702Z", "capitalBalanceUsd": 10000, "availableProfitUsd": 0, "profitSharePercent": 40, "totalPaidProfitUsd": 0, "totalReinvestedUsd": 0, "totalAccruedProfitUsd": 0}	2026-10-01 05:55:13.503763+00
user-admin:c72bed7ea0e03314bd7e998a514cb5b4	60d3890b56117e65f2ebc7c7d87278cb91394b432e3a830ed2a7d40f04142334	{"id": "owner-admin", "name": "Далер", "userId": "user-admin", "storeId": null, "createdAt": "2026-09-17T15:26:45.325Z", "capitalBalanceUsd": 55000, "availableProfitUsd": 696.69, "profitSharePercent": 60, "totalPaidProfitUsd": 0, "totalReinvestedUsd": 0, "totalAccruedProfitUsd": 696.69}	2026-10-01 05:55:43.674127+00
user-admin:756fa77e86579bd21015aebb02ff09ae	6975f6aa61305239b760629da42f3eec35e60f6bcdda7b2cbc7f0d9cd45b8a9a	{"id": "owner-partner-tsum", "name": "Сомон", "userId": "cf2c67ac-9da6-428a-9023-04041702fe8d", "storeId": "store-tsum", "createdAt": "2026-10-01T05:17:21.720Z", "capitalBalanceUsd": 20000, "availableProfitUsd": 0, "profitSharePercent": 40, "totalPaidProfitUsd": 0, "totalReinvestedUsd": 0, "totalAccruedProfitUsd": 0}	2026-10-01 05:55:56.857711+00
user-admin:9dbd5bbb2b200462a0bb18a2075ed36d	d6b6ab20478949673eb08a737d85c7e5851fda8193984ffefd58e1af7f7b985b	{"id": "owner-admin", "name": "Далер", "userId": "user-admin", "storeId": null, "createdAt": "2026-09-17T15:26:45.325Z", "capitalBalanceUsd": 105000, "availableProfitUsd": 696.69, "profitSharePercent": 60, "totalPaidProfitUsd": 0, "totalReinvestedUsd": 0, "totalAccruedProfitUsd": 696.69}	2026-10-01 05:56:21.74508+00
user-admin:5218c40ac60c92d197cdf59b8ae163d6	bd08f5fa78ab9cb06916b2d3c85b7996bf40084194683882f114603bea2c74fc	[{"id": "owner-admin", "name": "Далер", "userId": "user-admin", "storeId": null, "createdAt": "2026-09-17T15:26:45.325Z", "capitalBalanceUsd": 105000, "availableProfitUsd": 696.69, "profitSharePercent": 60, "totalPaidProfitUsd": 0, "totalReinvestedUsd": 0, "totalAccruedProfitUsd": 696.69}, {"id": "owner-partner-sadbarg", "name": "Рустам", "userId": "6d753871-ceb4-44bc-958a-b8fa4b75a6e5", "storeId": "store-sadbarg", "createdAt": "2026-10-01T05:17:21.683Z", "capitalBalanceUsd": 10000, "availableProfitUsd": 0, "profitSharePercent": 40, "totalPaidProfitUsd": 0, "totalReinvestedUsd": 0, "totalAccruedProfitUsd": 0}, {"id": "owner-partner-siyoma", "name": "Фаррух", "userId": "fcd65abe-134e-48c1-81d3-41704bc954b0", "storeId": "store-siyoma", "createdAt": "2026-10-01T05:17:21.702Z", "capitalBalanceUsd": 10000, "availableProfitUsd": 0, "profitSharePercent": 40, "totalPaidProfitUsd": 0, "totalReinvestedUsd": 0, "totalAccruedProfitUsd": 0}, {"id": "owner-partner-tsum", "name": "Сомон", "userId": "cf2c67ac-9da6-428a-9023-04041702fe8d", "storeId": "store-tsum", "createdAt": "2026-10-01T05:17:21.720Z", "capitalBalanceUsd": 20000, "availableProfitUsd": 0, "profitSharePercent": 40, "totalPaidProfitUsd": 0, "totalReinvestedUsd": 0, "totalAccruedProfitUsd": 0}]	2026-10-01 05:57:20.658027+00
user-admin:c31541ae56ad0be24169b708fc3521dc	26465d0d4db06bd770808f5aefff91280f98108202ac989b4840e68720c7363b	{"id": "owner-admin", "name": "Далер", "userId": "user-admin", "storeId": null, "createdAt": "2026-09-17T15:26:45.325Z", "capitalBalanceUsd": 105696.69, "availableProfitUsd": 0, "profitSharePercent": 60, "totalPaidProfitUsd": 0, "totalReinvestedUsd": 696.69, "totalAccruedProfitUsd": 696.69}	2026-10-01 05:57:44.335944+00
user-admin:843fd1a7b0b341f10b9a27c26c16fa4b	098fcefb02e98b2abdda567839411f7ef7288315afb46579558f52c7ec770e7a	{"id": "20787901-4b8e-469c-9bc2-26f3d08bd8f1", "paidAt": "2026-10-01T06:01:22.345Z", "status": "PAID", "comment": null, "storeId": "store-siyoma", "category": "UTILITIES", "amountTjs": 250, "amountUsd": 23.81, "createdAt": "2026-10-01T03:59:30.529Z", "employeeId": null, "targetType": "STORE", "cancelledAt": null, "description": "Оплата коммунальных услуг за текущий месяц", "exchangeRate": 10.5, "sourceAccount": "Центральная касса", "createdByUserId": "user-admin", "cancelledByUserId": null, "isEmployeeAdvance": false, "paidFromCashRegister": true, "ownerProfitAllocations": [{"ownerId": "owner-admin", "amountUsd": 23.81}]}	2026-10-01 06:01:22.234516+00
user-admin:288986b7c623dc95ebd28da8d90405a9	63de0268068b9194c1be4c80609557f24b22e53b4ab1d450f0839c34d2f6d44a	{"id": "6d753871-ceb4-44bc-958a-b8fa4b75a6e5", "name": "Рустам (Партнёр Садбарг)", "role": "PARTNER", "login": "partner_sadbarg", "store": {"id": "store-sadbarg", "name": "Магазин «Садбарг»"}, "active": true, "storeId": "store-sadbarg", "createdAt": "2026-10-01T05:17:21.675Z", "updatedAt": "2026-10-01T07:17:26.501Z", "baseSalaryTjs": 0, "salesCommissionPercent": 0}	2026-10-01 07:17:26.311893+00
user-admin:13fbb76e8914756267bb3ec1163cc7bf	e2116b9bd5da25a0be9e01da02d7966180f020f771b12a40968ae83bd2629dae	{"id": "6d753871-ceb4-44bc-958a-b8fa4b75a6e5", "name": "Рустам (Партнёр Садбарг)", "role": "PARTNER", "login": "partner_sadbarg", "store": {"id": "store-sadbarg", "name": "Магазин «Садбарг»"}, "active": true, "storeId": "store-sadbarg", "createdAt": "2026-10-01T05:17:21.675Z", "updatedAt": "2026-10-01T07:17:26.557Z", "baseSalaryTjs": 0, "salesCommissionPercent": 0}	2026-10-01 07:17:26.542418+00
\.


--
-- Data for Name: owner_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.owner_transactions (id, "ownerId", type, "amountUsd", "sourceOrDestination", "createdByUserId", note, "createdAt", "exchangeRate") FROM stdin;
1257245d-b623-43c1-b2da-b217e2cf79d7	owner-admin	INVESTMENT	10000.00	Магазин «Садбарг»	user-admin	\N	2026-10-01 05:54:24.912	10.5000
11a3f487-9b89-4606-a431-546d7d027c1f	owner-partner-sadbarg	INVESTMENT	10000.00	Магазин «Садбарг»	user-admin	\N	2026-10-01 05:54:46.51	10.5000
7e76805f-bd10-4ffd-bed4-03732d3908c0	owner-admin	INVESTMENT	20000.00	Магазин «Сиёма»	user-admin	\N	2026-10-01 05:55:00.87	10.5000
90e843c8-3bfc-4033-bea3-ba0924f196a9	owner-partner-siyoma	INVESTMENT	10000.00	Магазин «Сиёма»	user-admin	\N	2026-10-01 05:55:13.524	10.5000
6d65557a-dae4-41a0-9a5d-ed3c959ead24	owner-admin	INVESTMENT	25000.00	Магазин «ЦУМ»	user-admin	\N	2026-10-01 05:55:43.705	10.5000
84404c8c-aab2-4da4-ba41-70ccc30c42df	owner-partner-tsum	INVESTMENT	20000.00	Магазин «ЦУМ»	user-admin	\N	2026-10-01 05:55:56.872	10.5000
f3b533eb-c32c-48e1-9cb4-b26e1126f5ef	owner-admin	INVESTMENT	50000.00	Главный склад	user-admin	\N	2026-10-01 05:56:21.773	10.5000
1f5cae82-f1ae-41bf-88eb-e68d2a62bb7c	owner-admin	REINVEST	696.69	Главный склад	user-admin	\N	2026-10-01 05:57:44.362	10.5000
\.


--
-- Data for Name: owners; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.owners (id, name, "profitSharePercent", "capitalBalanceUsd", "totalAccruedProfitUsd", "totalPaidProfitUsd", "totalReinvestedUsd", "availableProfitUsd", "createdAt", "userId", "storeId") FROM stdin;
owner-admin	Далер	60.0000	105696.69	146.59	0.00	696.69	0.00	2026-09-17 15:26:45.325	user-admin	\N
owner-partner-siyoma	Фаррух	40.0000	10000.00	20.26	0.00	0.00	20.26	2026-10-01 05:17:21.702	fcd65abe-134e-48c1-81d3-41704bc954b0	store-siyoma
owner-partner-tsum	Сомон	40.0000	20000.00	38.60	0.00	0.00	38.60	2026-10-01 05:17:21.72	cf2c67ac-9da6-428a-9023-04041702fe8d	store-tsum
owner-partner-sadbarg	Рустам (Партнёр Садбарг)	40.0000	10000.00	38.86	0.00	0.00	38.86	2026-10-01 05:17:21.683	6d753871-ceb4-44bc-958a-b8fa4b75a6e5	store-sadbarg
\.


--
-- Data for Name: payroll_payouts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.payroll_payouts (expense_id, employee_id, month, gross_tjs, previous_salary_tjs, paid_advances_tjs, created_at) FROM stdin;
\.


--
-- Data for Name: quarter_closures; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.quarter_closures (id, "quarterName", "closedByUserId", snapshot, "closedAt") FROM stdin;
\.


--
-- Data for Name: repair_status_history; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repair_status_history (id, "ticketId", status, "updatedAt", "updatedByUserId", note) FROM stdin;
07142513-2f80-49b1-ba9d-fcb33a524fb9	fb9050d6-cffb-451a-b56f-8d19dc6b1abd	ACCEPTED	2026-10-01 03:59:30.396	user-admin	Прием телефона на ремонт
3f231518-c7b6-4ff1-84ca-146c1e058d5b	fb9050d6-cffb-451a-b56f-8d19dc6b1abd	IN_PROGRESS	2026-10-01 03:59:30.458	user-admin	Диагностика завершена, ремонт начат
b4834f84-da28-4d21-aef5-145509268b05	fb9050d6-cffb-451a-b56f-8d19dc6b1abd	READY	2026-10-01 04:17:06.001	user-admin	\N
76ba151a-f14b-4a9c-845f-c6c4248dbee0	fb9050d6-cffb-451a-b56f-8d19dc6b1abd	ISSUED	2026-10-01 04:17:14.371	user-admin	Выдано клиенту
\.


--
-- Data for Name: repair_tickets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.repair_tickets (id, "ticketNumber", "storeId", "userId", "deviceId", imei, imei2, brand, model, storage, color, "saleReceiptNumber", "saleDate", "customerName", "customerPhone", "prepaymentTjs", "problemDescription", "visualCondition", "equipmentPackage", comment, status, "estimatedCostTjs", "finalCostTjs", "createdAt", "updatedAt", "estimatedCostUsd", "exchangeRate", "finalCostUsd") FROM stdin;
fb9050d6-cffb-451a-b56f-8d19dc6b1abd	1	store-siyoma	user-admin	\N	357790827170362	\N	Samsung	Galaxy S24 Repair Audit	256GB	Phantom Black	\N	\N	\N	\N	\N	Замена дисплейного модуля	\N	\N	\N	ISSUED	\N	250.00	2026-10-01 03:59:30.396	2026-10-01 04:17:14.371	\N	10.5000	23.81
\.


--
-- Data for Name: sale_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sale_items (id, "saleId", "deviceId", brand, model, storage, color, imei, imei2, "salePriceTjs", "salePriceUsd", "purchaseCostUsd", "costBasisUsd", "isBelowCost", "isBonus") FROM stdin;
efff6d37-11e8-4f58-a79d-884520b81bcb	cf9a833f-bafb-4973-bf62-6dd5146cbd90	ec668089-8769-46ba-a770-601252eab3f9	Xiaomi	Redmi Note 13 Pro	256GB	Midnight Black	86100163137612	\N	2950.00	270.64	220.00	220.00	f	f
fa9850bf-b284-4d14-a1e7-7dbbfc031131	44e64a40-3208-44cd-9072-57704d02a2ef	982832be-aa97-48a2-8f7d-2da1c6333ad3	Samsung	Galaxy S24	256GB	Onyx Black	35200263137622	\N	8900.00	816.51	720.00	720.00	f	f
96f112be-d925-4ab4-914b-b8112ccccbaa	80d98632-1ec6-43a2-be8c-9136ca9bc162	fb0ee6fc-3bd4-4fea-a4da-271db90ddf29	Apple	iPhone 13	128GB	Starlight	35100363137632	\N	6400.00	587.16	490.00	490.00	f	f
\.


--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sales (id, "receiptNumber", "storeId", "userId", "customerName", "totalTjs", "totalUsd", "exchangeRate", "paymentMethod", "cashAmountTjs", "cardAmountTjs", "exchangeTradeInCreditTjs", status, "hasBelowCostItem", "refundReason", "refundedAt", "refundedByUserId", "penaltyFeeTjs", "penaltyFeeUsd", "actualRefundAmountTjs", "createdAt", "customerId", "debtAmountTjs") FROM stdin;
cf9a833f-bafb-4973-bf62-6dd5146cbd90	1	store-siyoma	user-admin	Рустам Исмаилов	2950.00	270.64	10.9000	CASH	2950.00	0.00	\N	COMPLETED	f	\N	\N	\N	\N	\N	\N	2026-10-01 03:50:31.523	\N	0.00
44e64a40-3208-44cd-9072-57704d02a2ef	2	store-tsum	user-admin	Мадина Саидова	8900.00	816.51	10.9000	CARD	0.00	8900.00	\N	COMPLETED	f	\N	\N	\N	\N	\N	\N	2026-10-01 03:50:31.574	\N	0.00
80d98632-1ec6-43a2-be8c-9136ca9bc162	3	store-sadbarg	user-admin	Алишер Назаров	6400.00	587.16	10.9000	SPLIT	4000.00	2400.00	\N	COMPLETED	f	\N	\N	\N	\N	\N	\N	2026-10-01 03:50:31.599	\N	0.00
\.


--
-- Data for Name: store_profit_shares; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.store_profit_shares (id, "storeId", "ownerId", "sharePercent", "updatedByUserId", "createdAt", "updatedAt") FROM stdin;
5e072982-1008-431b-bd09-24a7ea07e92f	store-sadbarg	owner-partner-sadbarg	40.0000	\N	2026-10-01 07:10:36.348	2026-10-01 07:10:36.348
999dbef1-7602-4eb6-b7e9-b98f771b4a1d	store-siyoma	owner-partner-siyoma	40.0000	\N	2026-10-01 07:10:36.348	2026-10-01 07:10:36.348
17c3486d-a256-402c-b3e3-4e4cf224dc53	store-tsum	owner-partner-tsum	40.0000	\N	2026-10-01 07:10:36.348	2026-10-01 07:10:36.348
\.


--
-- Data for Name: stores; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.stores (id, name, address, "isMainWarehouse", active, "createdAt", "updatedAt", "cashBalanceUsd") FROM stdin;
main-warehouse	Главный склад	ул. Джами 45	t	t	2026-09-17 15:26:44.947	2026-10-01 06:21:35.003	49976.19
store-sadbarg	Магазин «Садбарг»	ул. Айни 24	f	t	2026-10-01 03:50:31.361	2026-10-01 06:21:35.011	20380.95
store-siyoma	Магазин «Сиёма»	пр. Рудаки 82	f	t	2026-09-17 15:26:44.955	2026-10-01 06:21:35.016	30257.14
store-tsum	Магазин «ЦУМ»	пр. Рудаки 40	f	t	2026-10-01 03:50:31.35	2026-10-01 06:21:35.022	45000.00
\.


--
-- Data for Name: supplier_bonus_devices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplier_bonus_devices (id, "bonusId", "deviceId", brand, model, storage, color, imei, "costBasisUsd") FROM stdin;
\.


--
-- Data for Name: supplier_bonuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplier_bonuses (id, "supplierId", "campaignTitle", "bonusType", "amountUsd", status, "dateReceived", "createdAt", "exchangeRate", "ownerProfitAllocations") FROM stdin;
ac49ac74-fc7f-490b-8330-efae6d2e90b6	sup-dubai-wholesale	Квартальный бонус за объем (Apple Dubai)	CASH_DISCOUNT	500.00	IN_STOCK	2026-10-01 03:50:31.627	2026-10-01 03:50:31.627	10.9000	[{"ownerId": "owner-admin", "amountUsd": 500}]
\.


--
-- Data for Name: supplier_invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplier_invoices (id, "invoiceNumber", "supplierId", date, "totalAmountUsd", "paidAmountUsd", "devicesCount", "isStorePurchase", "storeId", "exchangeRate") FROM stdin;
9059ed95-f9aa-4200-b0b4-7664ce350923	INV-SIYOMA-631376	sup-dubai-wholesale	2026-10-01 03:50:31.376	1310.00	0.00	3	t	store-siyoma	10.9000
682becf3-486e-445e-97ff-e28d49fec071	INV-TSUM-631376	sup-dubai-wholesale	2026-10-01 03:50:31.43	2380.00	0.00	3	t	store-tsum	10.9000
e880a8ef-42d3-4415-a51c-1c7439a99792	INV-SADBARG-631376	sup-dubai-wholesale	2026-10-01 03:50:31.452	1210.00	0.00	3	t	store-sadbarg	10.9000
06806ace-8464-409d-a7e3-54204e7b5a82	INV-WH-631376	sup-dubai-wholesale	2026-10-01 03:50:31.475	2150.00	0.00	2	f	main-warehouse	10.9000
\.


--
-- Data for Name: supplier_payment_allocations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplier_payment_allocations (id, "paymentId", "invoiceId", "allocatedAmountUsd") FROM stdin;
\.


--
-- Data for Name: supplier_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.supplier_payments (id, "supplierId", "amountUsd", "sourceAccount", "storeId", "createdByUserId", "createdAt", "exchangeRate") FROM stdin;
\.


--
-- Data for Name: suppliers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.suppliers (id, name, phone, "contactPerson", "totalPurchasedUsd", "totalPaidUsd", "totalDebtUsd", active, "createdAt") FROM stdin;
sup-dubai-wholesale	Apple Dubai Wholesale LLC	+971 4 888 7777	Тарик	7050.00	0.00	7050.00	t	2026-10-01 03:50:31.371
\.


--
-- Data for Name: transfer_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transfer_items (id, "transferId", "deviceId", imei, model, brand) FROM stdin;
\.


--
-- Data for Name: transfer_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transfer_requests (id, "transferNumber", "fromStoreId", "toStoreId", status, "requestedByUserId", "requestedAt", "approvedByUserId", "approvedAt", "rejectedReason", "updatedAt") FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, login, password, name, role, active, "storeId", "baseSalaryTjs", "salesCommissionPercent", pin, "createdAt", "updatedAt") FROM stdin;
fcd65abe-134e-48c1-81d3-41704bc954b0	partner_siyoma	d4f8f2b0329961862547bcf595f4a5bf:82ede0f15e0bc297cd3e9395df073a87d44b496f1777c3451d5329ed118935000d078b2ce0f702a2759059ba7238b90a2972b5b9da972ffb31a022976664b1bf	Фаррух (Партнёр Сиёма)	PARTNER	t	store-siyoma	\N	\N	\N	2026-10-01 05:17:21.696	2026-10-01 06:21:35.283
d7d51c08-99da-4541-b267-6c430e60747f	seller_siyoma	04569bff5dd71aee2270d15e1c2e3b09:642480612f8e0fc26bdb104963be3312f70569e617178f898e9c1b1a722f3b8a2e62473a8d42b6c580c71a78e4fc2fc883b4a93a58cc2429258224bc39f5068e	Ахмад (Продавец Сиёма)	SELLER	t	store-siyoma	3000.00	0.0000	\N	2026-10-01 05:17:21.707	2026-10-01 06:21:35.294
user-admin	admin	5d6cfae0ff62e60365a9ffadaeb2b768:270986ef58429221bdd6fd54c10f87230b9dcca580c0b504a88758996101a0ecef70e13ac0ccf7a0445e90e9f99c76b0b7976539d65d6402688c75f58d6bb7c4	Далер	ADMIN	t	\N	\N	\N	\N	2026-09-17 15:26:45.052	2026-10-01 06:21:35.1
f4d04049-0f92-46f4-9109-c08dbd45cc10	seller_sadbarg	04569bff5dd71aee2270d15e1c2e3b09:642480612f8e0fc26bdb104963be3312f70569e617178f898e9c1b1a722f3b8a2e62473a8d42b6c580c71a78e4fc2fc883b4a93a58cc2429258224bc39f5068e	Алишер (Продавец Садбарг)	SELLER	t	store-sadbarg	3000.00	0.0000	\N	2026-10-01 05:17:21.689	2026-10-01 06:21:35.276
cf2c67ac-9da6-428a-9023-04041702fe8d	partner_tsum	d4f8f2b0329961862547bcf595f4a5bf:82ede0f15e0bc297cd3e9395df073a87d44b496f1777c3451d5329ed118935000d078b2ce0f702a2759059ba7238b90a2972b5b9da972ffb31a022976664b1bf	Сомон (Партнёр ЦУМ)	PARTNER	t	store-tsum	\N	\N	\N	2026-10-01 05:17:21.714	2026-10-01 06:21:35.3
1edc352a-cd6d-48af-9dde-eba89e5f7ad6	seller_tsum	04569bff5dd71aee2270d15e1c2e3b09:642480612f8e0fc26bdb104963be3312f70569e617178f898e9c1b1a722f3b8a2e62473a8d42b6c580c71a78e4fc2fc883b4a93a58cc2429258224bc39f5068e	Баходyp (Продавец ЦУМ)	SELLER	t	store-tsum	3000.00	0.0000	\N	2026-10-01 05:17:21.725	2026-10-01 06:21:35.313
6d753871-ceb4-44bc-958a-b8fa4b75a6e5	partner_sadbarg	26ceb0446cf570343cebe1e8a181d648:a75fcc2b35233c3de5e19f8fbb6f1e7b092cacc62f4dea220de667583accfce4dbe5322ebacfe96cd6a8f5f338650661af10c59982d3df3424dcd73dfdefaebb	Рустам (Партнёр Садбарг)	PARTNER	t	store-sadbarg	0.00	0.0000	\N	2026-10-01 05:17:21.675	2026-10-01 07:17:26.557
\.


--
-- Name: repair_tickets_ticketNumber_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."repair_tickets_ticketNumber_seq"', 1, true);


--
-- Name: sales_receiptNumber_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public."sales_receiptNumber_seq"', 3, true);


--
-- Name: _prisma_migrations _prisma_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._prisma_migrations
    ADD CONSTRAINT _prisma_migrations_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: auth_sessions auth_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_pkey PRIMARY KEY (id);


--
-- Name: bonus_distribution_logs bonus_distribution_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bonus_distribution_logs
    ADD CONSTRAINT bonus_distribution_logs_pkey PRIMARY KEY (id);


--
-- Name: bonus_pool_entries bonus_pool_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bonus_pool_entries
    ADD CONSTRAINT bonus_pool_entries_pkey PRIMARY KEY (id);


--
-- Name: cash_handovers cash_handovers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_handovers
    ADD CONSTRAINT cash_handovers_pkey PRIMARY KEY (id);


--
-- Name: customer_payment_allocations customer_payment_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_payment_allocations
    ADD CONSTRAINT customer_payment_allocations_pkey PRIMARY KEY (id);


--
-- Name: customer_payments customer_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_payments
    ADD CONSTRAINT customer_payments_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: device_identifiers device_identifiers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_identifiers
    ADD CONSTRAINT device_identifiers_pkey PRIMARY KEY (identifier);


--
-- Name: device_timeline_events device_timeline_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_timeline_events
    ADD CONSTRAINT device_timeline_events_pkey PRIMARY KEY (id);


--
-- Name: devices devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT devices_pkey PRIMARY KEY (id);


--
-- Name: document_sequences document_sequences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_sequences
    ADD CONSTRAINT document_sequences_pkey PRIMARY KEY (key);


--
-- Name: exchange_events exchange_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exchange_events
    ADD CONSTRAINT exchange_events_pkey PRIMARY KEY (id);


--
-- Name: exchange_rates exchange_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exchange_rates
    ADD CONSTRAINT exchange_rates_pkey PRIMARY KEY (id);


--
-- Name: expenses expenses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT expenses_pkey PRIMARY KEY (id);


--
-- Name: financial_accounts financial_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_accounts
    ADD CONSTRAINT financial_accounts_pkey PRIMARY KEY (id);


--
-- Name: financial_categories financial_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_categories
    ADD CONSTRAINT financial_categories_pkey PRIMARY KEY (id);


--
-- Name: financial_transactions financial_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT financial_transactions_pkey PRIMARY KEY (id);


--
-- Name: invoice_groups invoice_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_groups
    ADD CONSTRAINT invoice_groups_pkey PRIMARY KEY (id);


--
-- Name: ledger_entries ledger_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ledger_entries
    ADD CONSTRAINT ledger_entries_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: operation_requests operation_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.operation_requests
    ADD CONSTRAINT operation_requests_pkey PRIMARY KEY (key);


--
-- Name: owner_transactions owner_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.owner_transactions
    ADD CONSTRAINT owner_transactions_pkey PRIMARY KEY (id);


--
-- Name: owners owners_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.owners
    ADD CONSTRAINT owners_pkey PRIMARY KEY (id);


--
-- Name: payroll_payouts payroll_payouts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_payouts
    ADD CONSTRAINT payroll_payouts_pkey PRIMARY KEY (expense_id);


--
-- Name: quarter_closures quarter_closures_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.quarter_closures
    ADD CONSTRAINT quarter_closures_pkey PRIMARY KEY (id);


--
-- Name: repair_status_history repair_status_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_status_history
    ADD CONSTRAINT repair_status_history_pkey PRIMARY KEY (id);


--
-- Name: repair_tickets repair_tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_tickets
    ADD CONSTRAINT repair_tickets_pkey PRIMARY KEY (id);


--
-- Name: sale_items sale_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_items
    ADD CONSTRAINT sale_items_pkey PRIMARY KEY (id);


--
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (id);


--
-- Name: store_profit_shares store_profit_shares_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_profit_shares
    ADD CONSTRAINT store_profit_shares_pkey PRIMARY KEY (id);


--
-- Name: stores stores_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.stores
    ADD CONSTRAINT stores_pkey PRIMARY KEY (id);


--
-- Name: supplier_bonus_devices supplier_bonus_devices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_bonus_devices
    ADD CONSTRAINT supplier_bonus_devices_pkey PRIMARY KEY (id);


--
-- Name: supplier_bonuses supplier_bonuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_bonuses
    ADD CONSTRAINT supplier_bonuses_pkey PRIMARY KEY (id);


--
-- Name: supplier_invoices supplier_invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_invoices
    ADD CONSTRAINT supplier_invoices_pkey PRIMARY KEY (id);


--
-- Name: supplier_payment_allocations supplier_payment_allocations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_payment_allocations
    ADD CONSTRAINT supplier_payment_allocations_pkey PRIMARY KEY (id);


--
-- Name: supplier_payments supplier_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_payments
    ADD CONSTRAINT supplier_payments_pkey PRIMARY KEY (id);


--
-- Name: suppliers suppliers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.suppliers
    ADD CONSTRAINT suppliers_pkey PRIMARY KEY (id);


--
-- Name: transfer_items transfer_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transfer_items
    ADD CONSTRAINT transfer_items_pkey PRIMARY KEY (id);


--
-- Name: transfer_requests transfer_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transfer_requests
    ADD CONSTRAINT transfer_requests_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: audit_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "audit_logs_createdAt_idx" ON public.audit_logs USING btree ("createdAt");


--
-- Name: audit_logs_targetId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "audit_logs_targetId_idx" ON public.audit_logs USING btree ("targetId");


--
-- Name: auth_sessions_userId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "auth_sessions_userId_idx" ON public.auth_sessions USING btree ("userId");


--
-- Name: bonus_distribution_logs_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "bonus_distribution_logs_createdAt_idx" ON public.bonus_distribution_logs USING btree ("createdAt");


--
-- Name: bonus_pool_entries_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "bonus_pool_entries_createdAt_idx" ON public.bonus_pool_entries USING btree ("createdAt");


--
-- Name: bonus_pool_entries_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX bonus_pool_entries_status_idx ON public.bonus_pool_entries USING btree (status);


--
-- Name: cash_handovers_businessDate_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "cash_handovers_businessDate_idx" ON public.cash_handovers USING btree ("businessDate");


--
-- Name: cash_handovers_financialTransactionId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "cash_handovers_financialTransactionId_key" ON public.cash_handovers USING btree ("financialTransactionId");


--
-- Name: cash_handovers_storeId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "cash_handovers_storeId_createdAt_idx" ON public.cash_handovers USING btree ("storeId", "createdAt");


--
-- Name: customer_payment_allocations_paymentId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "customer_payment_allocations_paymentId_idx" ON public.customer_payment_allocations USING btree ("paymentId");


--
-- Name: customer_payment_allocations_saleId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "customer_payment_allocations_saleId_idx" ON public.customer_payment_allocations USING btree ("saleId");


--
-- Name: customer_payments_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "customer_payments_customerId_idx" ON public.customer_payments USING btree ("customerId");


--
-- Name: customers_phone_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX customers_phone_key ON public.customers USING btree (phone);


--
-- Name: device_identifiers_device_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX device_identifiers_device_idx ON public.device_identifiers USING btree (device_id);


--
-- Name: device_timeline_events_deviceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "device_timeline_events_deviceId_idx" ON public.device_timeline_events USING btree ("deviceId");


--
-- Name: devices_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "devices_createdAt_idx" ON public.devices USING btree ("createdAt");


--
-- Name: devices_imei2_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX devices_imei2_key ON public.devices USING btree (imei2);


--
-- Name: devices_imei_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX devices_imei_idx ON public.devices USING btree (imei);


--
-- Name: devices_imei_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX devices_imei_key ON public.devices USING btree (imei);


--
-- Name: devices_purchaseInvoiceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "devices_purchaseInvoiceId_idx" ON public.devices USING btree ("purchaseInvoiceId");


--
-- Name: devices_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX devices_status_idx ON public.devices USING btree (status);


--
-- Name: devices_storeId_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "devices_storeId_status_idx" ON public.devices USING btree ("storeId", status);


--
-- Name: devices_supplierId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "devices_supplierId_idx" ON public.devices USING btree ("supplierId");


--
-- Name: exchange_rates_date_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX exchange_rates_date_key ON public.exchange_rates USING btree (date);


--
-- Name: expenses_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "expenses_createdAt_idx" ON public.expenses USING btree ("createdAt");


--
-- Name: expenses_employeeId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "expenses_employeeId_idx" ON public.expenses USING btree ("employeeId");


--
-- Name: expenses_storeId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "expenses_storeId_createdAt_idx" ON public.expenses USING btree ("storeId", "createdAt");


--
-- Name: financial_accounts_storeId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "financial_accounts_storeId_key" ON public.financial_accounts USING btree ("storeId");


--
-- Name: financial_transactions_accountId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "financial_transactions_accountId_idx" ON public.financial_transactions USING btree ("accountId");


--
-- Name: financial_transactions_categoryId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "financial_transactions_categoryId_idx" ON public.financial_transactions USING btree ("categoryId");


--
-- Name: financial_transactions_counterpartyType_counterpartyId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "financial_transactions_counterpartyType_counterpartyId_idx" ON public.financial_transactions USING btree ("counterpartyType", "counterpartyId");


--
-- Name: financial_transactions_idempotencyKey_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "financial_transactions_idempotencyKey_key" ON public.financial_transactions USING btree ("idempotencyKey");


--
-- Name: financial_transactions_reversedTransactionId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "financial_transactions_reversedTransactionId_key" ON public.financial_transactions USING btree ("reversedTransactionId");


--
-- Name: financial_transactions_shopId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "financial_transactions_shopId_idx" ON public.financial_transactions USING btree ("shopId");


--
-- Name: financial_transactions_sourceType_sourceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "financial_transactions_sourceType_sourceId_idx" ON public.financial_transactions USING btree ("sourceType", "sourceId");


--
-- Name: financial_transactions_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX financial_transactions_status_idx ON public.financial_transactions USING btree (status);


--
-- Name: financial_transactions_transactionDate_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "financial_transactions_transactionDate_idx" ON public.financial_transactions USING btree ("transactionDate");


--
-- Name: financial_transactions_transactionNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "financial_transactions_transactionNumber_key" ON public.financial_transactions USING btree ("transactionNumber");


--
-- Name: invoice_groups_invoiceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "invoice_groups_invoiceId_idx" ON public.invoice_groups USING btree ("invoiceId");


--
-- Name: ledger_entries_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "ledger_entries_createdAt_idx" ON public.ledger_entries USING btree ("createdAt");


--
-- Name: notifications_targetRole_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "notifications_targetRole_createdAt_idx" ON public.notifications USING btree ("targetRole", "createdAt");


--
-- Name: notifications_targetRole_read_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "notifications_targetRole_read_idx" ON public.notifications USING btree ("targetRole", read);


--
-- Name: notifications_targetUserId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "notifications_targetUserId_createdAt_idx" ON public.notifications USING btree ("targetUserId", "createdAt");


--
-- Name: notifications_targetUserId_read_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "notifications_targetUserId_read_idx" ON public.notifications USING btree ("targetUserId", read);


--
-- Name: owner_transactions_ownerId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "owner_transactions_ownerId_createdAt_idx" ON public.owner_transactions USING btree ("ownerId", "createdAt");


--
-- Name: owners_userId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "owners_userId_key" ON public.owners USING btree ("userId");


--
-- Name: payroll_payouts_employee_month_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX payroll_payouts_employee_month_idx ON public.payroll_payouts USING btree (employee_id, month);


--
-- Name: repair_tickets_storeId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "repair_tickets_storeId_createdAt_idx" ON public.repair_tickets USING btree ("storeId", "createdAt");


--
-- Name: repair_tickets_storeId_status_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "repair_tickets_storeId_status_idx" ON public.repair_tickets USING btree ("storeId", status);


--
-- Name: repair_tickets_ticketNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "repair_tickets_ticketNumber_key" ON public.repair_tickets USING btree ("ticketNumber");


--
-- Name: sale_items_deviceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sale_items_deviceId_idx" ON public.sale_items USING btree ("deviceId");


--
-- Name: sale_items_saleId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sale_items_saleId_idx" ON public.sale_items USING btree ("saleId");


--
-- Name: sales_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sales_createdAt_idx" ON public.sales USING btree ("createdAt");


--
-- Name: sales_customerId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sales_customerId_idx" ON public.sales USING btree ("customerId");


--
-- Name: sales_receiptNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "sales_receiptNumber_key" ON public.sales USING btree ("receiptNumber");


--
-- Name: sales_storeId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sales_storeId_createdAt_idx" ON public.sales USING btree ("storeId", "createdAt");


--
-- Name: sales_userId_createdAt_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "sales_userId_createdAt_idx" ON public.sales USING btree ("userId", "createdAt");


--
-- Name: store_profit_shares_storeId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "store_profit_shares_storeId_idx" ON public.store_profit_shares USING btree ("storeId");


--
-- Name: store_profit_shares_storeId_ownerId_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "store_profit_shares_storeId_ownerId_key" ON public.store_profit_shares USING btree ("storeId", "ownerId");


--
-- Name: supplier_invoices_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX supplier_invoices_date_idx ON public.supplier_invoices USING btree (date);


--
-- Name: supplier_invoices_storeId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "supplier_invoices_storeId_idx" ON public.supplier_invoices USING btree ("storeId");


--
-- Name: supplier_invoices_supplierId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "supplier_invoices_supplierId_idx" ON public.supplier_invoices USING btree ("supplierId");


--
-- Name: transfer_items_deviceId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "transfer_items_deviceId_idx" ON public.transfer_items USING btree ("deviceId");


--
-- Name: transfer_items_transferId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "transfer_items_transferId_idx" ON public.transfer_items USING btree ("transferId");


--
-- Name: transfer_requests_fromStoreId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "transfer_requests_fromStoreId_idx" ON public.transfer_requests USING btree ("fromStoreId");


--
-- Name: transfer_requests_toStoreId_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "transfer_requests_toStoreId_idx" ON public.transfer_requests USING btree ("toStoreId");


--
-- Name: transfer_requests_transferNumber_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX "transfer_requests_transferNumber_key" ON public.transfer_requests USING btree ("transferNumber");


--
-- Name: users_login_key; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX users_login_key ON public.users USING btree (login);


--
-- Name: devices device_identifiers_sync; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER device_identifiers_sync AFTER INSERT OR UPDATE OF imei, imei2 ON public.devices FOR EACH ROW EXECUTE FUNCTION public.sync_device_identifiers();


--
-- Name: audit_logs audit_logs_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT "audit_logs_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: auth_sessions auth_sessions_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT "auth_sessions_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bonus_pool_entries bonus_pool_entries_deviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bonus_pool_entries
    ADD CONSTRAINT "bonus_pool_entries_deviceId_fkey" FOREIGN KEY ("deviceId") REFERENCES public.devices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: bonus_pool_entries bonus_pool_entries_saleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bonus_pool_entries
    ADD CONSTRAINT "bonus_pool_entries_saleId_fkey" FOREIGN KEY ("saleId") REFERENCES public.sales(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: cash_handovers cash_handovers_storeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cash_handovers
    ADD CONSTRAINT "cash_handovers_storeId_fkey" FOREIGN KEY ("storeId") REFERENCES public.stores(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: customer_payment_allocations customer_payment_allocations_paymentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_payment_allocations
    ADD CONSTRAINT "customer_payment_allocations_paymentId_fkey" FOREIGN KEY ("paymentId") REFERENCES public.customer_payments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: customer_payment_allocations customer_payment_allocations_saleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_payment_allocations
    ADD CONSTRAINT "customer_payment_allocations_saleId_fkey" FOREIGN KEY ("saleId") REFERENCES public.sales(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: customer_payments customer_payments_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.customer_payments
    ADD CONSTRAINT "customer_payments_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: device_identifiers device_identifiers_device_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_identifiers
    ADD CONSTRAINT device_identifiers_device_id_fkey FOREIGN KEY (device_id) REFERENCES public.devices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: device_timeline_events device_timeline_events_deviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_timeline_events
    ADD CONSTRAINT "device_timeline_events_deviceId_fkey" FOREIGN KEY ("deviceId") REFERENCES public.devices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: devices devices_purchaseInvoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT "devices_purchaseInvoiceId_fkey" FOREIGN KEY ("purchaseInvoiceId") REFERENCES public.supplier_invoices(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: devices devices_storeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT "devices_storeId_fkey" FOREIGN KEY ("storeId") REFERENCES public.stores(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: devices devices_supplierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.devices
    ADD CONSTRAINT "devices_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: exchange_events exchange_events_saleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.exchange_events
    ADD CONSTRAINT "exchange_events_saleId_fkey" FOREIGN KEY ("saleId") REFERENCES public.sales(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: expenses expenses_storeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.expenses
    ADD CONSTRAINT "expenses_storeId_fkey" FOREIGN KEY ("storeId") REFERENCES public.stores(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: financial_accounts financial_accounts_storeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_accounts
    ADD CONSTRAINT "financial_accounts_storeId_fkey" FOREIGN KEY ("storeId") REFERENCES public.stores(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: financial_categories financial_categories_parentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_categories
    ADD CONSTRAINT "financial_categories_parentId_fkey" FOREIGN KEY ("parentId") REFERENCES public.financial_categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: financial_transactions financial_transactions_accountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT "financial_transactions_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES public.financial_accounts(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: financial_transactions financial_transactions_categoryId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT "financial_transactions_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES public.financial_categories(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: financial_transactions financial_transactions_destinationAccountId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT "financial_transactions_destinationAccountId_fkey" FOREIGN KEY ("destinationAccountId") REFERENCES public.financial_accounts(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: financial_transactions financial_transactions_shopId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT "financial_transactions_shopId_fkey" FOREIGN KEY ("shopId") REFERENCES public.stores(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: invoice_groups invoice_groups_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_groups
    ADD CONSTRAINT "invoice_groups_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.supplier_invoices(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: notifications notifications_targetUserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT "notifications_targetUserId_fkey" FOREIGN KEY ("targetUserId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: owner_transactions owner_transactions_ownerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.owner_transactions
    ADD CONSTRAINT "owner_transactions_ownerId_fkey" FOREIGN KEY ("ownerId") REFERENCES public.owners(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: owners owners_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.owners
    ADD CONSTRAINT "owners_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: payroll_payouts payroll_payouts_employee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_payouts
    ADD CONSTRAINT payroll_payouts_employee_id_fkey FOREIGN KEY (employee_id) REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: payroll_payouts payroll_payouts_expense_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payroll_payouts
    ADD CONSTRAINT payroll_payouts_expense_id_fkey FOREIGN KEY (expense_id) REFERENCES public.expenses(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: repair_status_history repair_status_history_ticketId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_status_history
    ADD CONSTRAINT "repair_status_history_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES public.repair_tickets(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: repair_tickets repair_tickets_deviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_tickets
    ADD CONSTRAINT "repair_tickets_deviceId_fkey" FOREIGN KEY ("deviceId") REFERENCES public.devices(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: repair_tickets repair_tickets_storeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_tickets
    ADD CONSTRAINT "repair_tickets_storeId_fkey" FOREIGN KEY ("storeId") REFERENCES public.stores(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: repair_tickets repair_tickets_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repair_tickets
    ADD CONSTRAINT "repair_tickets_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sale_items sale_items_deviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_items
    ADD CONSTRAINT "sale_items_deviceId_fkey" FOREIGN KEY ("deviceId") REFERENCES public.devices(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sale_items sale_items_saleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sale_items
    ADD CONSTRAINT "sale_items_saleId_fkey" FOREIGN KEY ("saleId") REFERENCES public.sales(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: sales sales_customerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT "sales_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES public.customers(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: sales sales_storeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT "sales_storeId_fkey" FOREIGN KEY ("storeId") REFERENCES public.stores(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: sales sales_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT "sales_userId_fkey" FOREIGN KEY ("userId") REFERENCES public.users(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: store_profit_shares store_profit_shares_ownerId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_profit_shares
    ADD CONSTRAINT "store_profit_shares_ownerId_fkey" FOREIGN KEY ("ownerId") REFERENCES public.owners(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: store_profit_shares store_profit_shares_storeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.store_profit_shares
    ADD CONSTRAINT "store_profit_shares_storeId_fkey" FOREIGN KEY ("storeId") REFERENCES public.stores(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: supplier_bonus_devices supplier_bonus_devices_bonusId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_bonus_devices
    ADD CONSTRAINT "supplier_bonus_devices_bonusId_fkey" FOREIGN KEY ("bonusId") REFERENCES public.supplier_bonuses(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: supplier_bonuses supplier_bonuses_supplierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_bonuses
    ADD CONSTRAINT "supplier_bonuses_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: supplier_invoices supplier_invoices_storeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_invoices
    ADD CONSTRAINT "supplier_invoices_storeId_fkey" FOREIGN KEY ("storeId") REFERENCES public.stores(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: supplier_invoices supplier_invoices_supplierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_invoices
    ADD CONSTRAINT "supplier_invoices_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: supplier_payment_allocations supplier_payment_allocations_invoiceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_payment_allocations
    ADD CONSTRAINT "supplier_payment_allocations_invoiceId_fkey" FOREIGN KEY ("invoiceId") REFERENCES public.supplier_invoices(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: supplier_payment_allocations supplier_payment_allocations_paymentId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_payment_allocations
    ADD CONSTRAINT "supplier_payment_allocations_paymentId_fkey" FOREIGN KEY ("paymentId") REFERENCES public.supplier_payments(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: supplier_payments supplier_payments_supplierId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.supplier_payments
    ADD CONSTRAINT "supplier_payments_supplierId_fkey" FOREIGN KEY ("supplierId") REFERENCES public.suppliers(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: transfer_items transfer_items_deviceId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transfer_items
    ADD CONSTRAINT "transfer_items_deviceId_fkey" FOREIGN KEY ("deviceId") REFERENCES public.devices(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: transfer_items transfer_items_transferId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transfer_items
    ADD CONSTRAINT "transfer_items_transferId_fkey" FOREIGN KEY ("transferId") REFERENCES public.transfer_requests(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: transfer_requests transfer_requests_fromStoreId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transfer_requests
    ADD CONSTRAINT "transfer_requests_fromStoreId_fkey" FOREIGN KEY ("fromStoreId") REFERENCES public.stores(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: transfer_requests transfer_requests_toStoreId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transfer_requests
    ADD CONSTRAINT "transfer_requests_toStoreId_fkey" FOREIGN KEY ("toStoreId") REFERENCES public.stores(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- Name: users users_storeId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT "users_storeId_fkey" FOREIGN KEY ("storeId") REFERENCES public.stores(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict aneZmiEsNBDKPz0D5FngThvtyaAPznLdsZdyhqr7PpnLqEUSnTdWmoqD0hfNU0e

